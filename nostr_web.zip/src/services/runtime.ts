import { NavigationState, NostrSiteMeta, SiteFile } from '../types';

export interface ResolvedNavigation {
  targetHtmlBlobUrl: string;
  normalizedPath: string;
  search: string;
  hash: string;
  title: string;
}

/**
 * Parses a combined WebP2P URL string into siteAddress, path, search and hash.
 * E.g.: "naddr1.../posts/intro.html?theme=dark&page=2#top"
 */
export function parseWebp2pAddress(fullUrl: string): {
  rawSiteAddress: string;
  path: string;
  search: string;
  hash: string;
  searchParams: Record<string, string>;
} {
  let working = fullUrl.trim().replace(/^webp2p:\/\//, '').replace(/^nostr:/, '');

  let hash = '';
  const hashIdx = working.indexOf('#');
  if (hashIdx !== -1) {
    hash = working.substring(hashIdx);
    working = working.substring(0, hashIdx);
  }

  let search = '';
  const searchIdx = working.indexOf('?');
  if (searchIdx !== -1) {
    search = working.substring(searchIdx);
    working = working.substring(0, searchIdx);
  }

  // Parse searchParams
  const searchParams: Record<string, string> = {};
  if (search.length > 1) {
    const sp = new URLSearchParams(search);
    sp.forEach((val, key) => {
      searchParams[key] = val;
    });
  }

  // Determine site address vs subpath
  let rawSiteAddress = working;
  let path = '/index.html';

  if (working.startsWith('naddr1')) {
    const slashIdx = working.indexOf('/');
    if (slashIdx !== -1) {
      rawSiteAddress = working.substring(0, slashIdx);
      path = working.substring(slashIdx);
    } else {
      rawSiteAddress = working;
      path = '/index.html';
    }
  } else if (working.startsWith('npub1') || /^[0-9a-fA-F]{64}\//.test(working)) {
    // Format: npub1.../dTag/subpath or pubkey/dTag/subpath
    const parts = working.split('/');
    if (parts.length >= 2) {
      rawSiteAddress = `${parts[0]}/${parts[1]}`;
      if (parts.length > 2) {
        path = '/' + parts.slice(2).join('/');
      } else {
        path = '/index.html';
      }
    }
  } else if (working.includes('/')) {
    const slashIdx = working.indexOf('/');
    rawSiteAddress = working.substring(0, slashIdx);
    path = working.substring(slashIdx);
  }

  if (!path || path === '/') {
    path = '/index.html';
  }

  return {
    rawSiteAddress,
    path,
    search,
    hash,
    searchParams,
  };
}

/**
 * Normalizes relative paths within a site.
 */
export function resolveRelativePath(basePath: string, relativePath: string): string {
  if (relativePath.startsWith('/')) {
    return relativePath.replace(/^\/+/, '');
  }

  const baseParts = basePath.replace(/^\/+/, '').split('/');
  baseParts.pop(); // Remove file name

  const relParts = relativePath.split('/');
  for (const part of relParts) {
    if (part === '.' || part === '') continue;
    if (part === '..') {
      baseParts.pop();
    } else {
      baseParts.push(part);
    }
  }

  return baseParts.join('/');
}

// Map to hold active blob URLs for clean disposal
const activeBlobUrls = new Set<string>();

export function revokeAllRuntimeBlobs() {
  activeBlobUrls.forEach((url) => {
    try {
      URL.revokeObjectURL(url);
    } catch {}
  });
  activeBlobUrls.clear();
}

/**
 * Prepares and builds an HTML document from the virtual file bundle,
 * rewrites assets (CSS, JS, images) into Object URLs, and injects the WebP2P Navigation Bridge.
 */
export function renderSiteToBlobUrl(
  files: Record<string, SiteFile>,
  currentPath: string,
  search: string,
  hash: string,
  siteMeta?: NostrSiteMeta
): ResolvedNavigation {
  // Normalize current path
  let lookupPath = currentPath.replace(/^\/+/, '');
  if (!lookupPath || lookupPath === '' || lookupPath === '/') {
    lookupPath = siteMeta?.entrypoint || 'index.html';
  }

  // Look for target HTML file
  let fileEntry = files[lookupPath];
  if (!fileEntry) {
    // Try appending .html
    if (files[`${lookupPath}.html`]) {
      lookupPath = `${lookupPath}.html`;
      fileEntry = files[lookupPath];
    } else if (files[`${lookupPath}/index.html`]) {
      lookupPath = `${lookupPath}/index.html`;
      fileEntry = files[lookupPath];
    } else if (files['index.html']) {
      lookupPath = 'index.html';
      fileEntry = files['index.html'];
    }
  }

  if (!fileEntry) {
    // 404 fallback page
    const notFoundHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>404 - Arquivo não encontrado</title>
          <style>
            body { font-family: system-ui, sans-serif; background: #0f172a; color: #f8fafc; padding: 3rem; text-align: center; }
            h1 { font-size: 2rem; color: #f43f5e; margin-bottom: 1rem; }
            p { color: #94a3b8; max-width: 500px; margin: 0 auto 1.5rem auto; line-height: 1.6; }
            .btn { background: #6366f1; color: white; padding: 0.6rem 1.2rem; border-radius: 6px; text-decoration: none; font-weight: bold; }
            .files { text-align: left; max-width: 500px; margin: 2rem auto; background: #1e293b; padding: 1rem; border-radius: 8px; font-family: monospace; font-size: 0.85rem; }
          </style>
        </head>
        <body>
          <h1>404: Arquivo Não Encontrado</h1>
          <p>O arquivo <code>/${lookupPath}</code> não foi encontrado neste site estático Nostr.</p>
          <a href="index.html" class="btn">Voltar para o Início</a>
          <div class="files">
            <strong>Arquivos disponíveis no pacote:</strong>
            <ul style="margin-top: 0.5rem; padding-left: 1.2rem;">
              ${Object.keys(files)
                .map((k) => `<li>${k}</li>`)
                .join('')}
            </ul>
          </div>
        </body>
      </html>
    `;
    const blob = new Blob([notFoundHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    activeBlobUrls.add(url);
    return {
      targetHtmlBlobUrl: url,
      normalizedPath: `/${lookupPath}`,
      search,
      hash,
      title: '404 - Não encontrado',
    };
  }

  let htmlContent =
    typeof fileEntry.content === 'string'
      ? fileEntry.content
      : new TextDecoder().decode(fileEntry.content as ArrayBuffer);

  // Extract page title if available
  const titleMatch = htmlContent.match(/<title>([^<]*)<\/title>/i);
  const title = titleMatch ? titleMatch[1] : siteMeta?.title || 'WebP2P Site';

  // Build Object URLs dictionary for all non-HTML files (images, css, scripts, fonts)
  const fileUrlMap = new Map<string, string>();
  for (const [p, f] of Object.entries(files)) {
    if (f.mimeType !== 'text/html') {
      const blob =
        f.content instanceof ArrayBuffer
          ? new Blob([f.content], { type: f.mimeType })
          : new Blob([f.content as string], { type: f.mimeType });
      const objectUrl = URL.createObjectURL(blob);
      activeBlobUrls.add(objectUrl);
      fileUrlMap.set(p, objectUrl);
    }
  }

  // Replace asset references in HTML (e.g. href="style.css", src="image.png")
  // We use regex to match relative asset references
  htmlContent = htmlContent.replace(
    /(<(?:link|script|img|source|video|audio)[^>]+?(?:src|href)=["'])([^"':#?]+)(["'])/gi,
    (match, prefix, refPath, suffix) => {
      // Don't touch external URLs or anchors
      if (
        refPath.startsWith('http://') ||
        refPath.startsWith('https://') ||
        refPath.startsWith('//') ||
        refPath.startsWith('data:') ||
        refPath.startsWith('blob:') ||
        refPath.startsWith('#')
      ) {
        return match;
      }

      // Check if it links to an HTML file - leave HTML links for the navigation bridge!
      if (refPath.endsWith('.html') || refPath.endsWith('.htm')) {
        return match;
      }

      const resolved = resolveRelativePath(lookupPath, refPath);
      const mappedUrl = fileUrlMap.get(resolved) || fileUrlMap.get(refPath);

      if (mappedUrl) {
        return `${prefix}${mappedUrl}${suffix}`;
      }
      return match;
    }
  );

  // Client Bridge Script:
  // Injects simulated window.location parameters, hooks pushState/replaceState,
  // intercepts <a> clicks, and sends messages to parent WebP2P browser.
  const bridgeScript = `
    <script>
      (function() {
        let isInitializing = true;
        const CURRENT_PATH = ${JSON.stringify('/' + lookupPath)};
        const CURRENT_SEARCH = ${JSON.stringify(search)};
        const CURRENT_HASH = ${JSON.stringify(hash)};

        // 1. Ensure location and history reflect query params & hash on startup
        try {
          if (CURRENT_SEARCH || CURRENT_HASH) {
            history.replaceState(null, '', window.location.pathname + CURRENT_SEARCH + CURRENT_HASH);
          }
        } catch(e) {}
        isInitializing = false;

        // 2. Override location getters and setters so window.location.search and window.location.href
        // seamlessly reflect parameters and handle location.href = ... assignments
        try {
          if (CURRENT_SEARCH) {
            try {
              Object.defineProperty(window.location, 'search', {
                get: function() { return CURRENT_SEARCH; },
                configurable: true
              });
            } catch(e) {
              try {
                Object.defineProperty(Location.prototype, 'search', {
                  get: function() { return CURRENT_SEARCH; },
                  configurable: true
                });
              } catch(e2) {}
            }
          }

          let currentHref = (window.location.origin || '') + window.location.pathname + CURRENT_SEARCH + CURRENT_HASH;
          function getHref() {
            return currentHref;
          }
          function setHref(newUrl) {
            currentHref = String(newUrl);
            window.parent.postMessage({
              type: 'WEBP2P_NAVIGATE',
              href: String(newUrl),
              basePath: CURRENT_PATH
            }, '*');
          }

          try {
            Object.defineProperty(window.location, 'href', {
              get: getHref,
              set: setHref,
              configurable: true
            });
          } catch(e) {
            try {
              Object.defineProperty(Location.prototype, 'href', {
                get: getHref,
                set: setHref,
                configurable: true
              });
            } catch(e2) {}
          }
        } catch(e) {}

        // 3. Patch URL constructor so new URL(window.location.href) contains CURRENT_SEARCH
        try {
          const OrigURL = window.URL;
          function Webp2pURL(input, base) {
            let targetInput = input;
            if (
              (targetInput === window.location.href || (typeof targetInput === 'string' && targetInput.startsWith('blob:'))) &&
              CURRENT_SEARCH &&
              !targetInput.includes('?')
            ) {
              targetInput = targetInput + CURRENT_SEARCH + (CURRENT_HASH || '');
            }
            const instance = arguments.length > 1 && base !== undefined
              ? new OrigURL(targetInput, base)
              : new OrigURL(targetInput);

            if (
              (input === window.location.href || input === '' || input === undefined) &&
              CURRENT_SEARCH &&
              instance.searchParams &&
              instance.searchParams.size === 0
            ) {
              const sp = new URLSearchParams(CURRENT_SEARCH);
              sp.forEach(function(v, k) { instance.searchParams.set(k, v); });
            }
            return instance;
          }
          Webp2pURL.prototype = OrigURL.prototype;
          Webp2pURL.createObjectURL = OrigURL.createObjectURL;
          Webp2pURL.revokeObjectURL = OrigURL.revokeObjectURL;
          window.URL = Webp2pURL;
        } catch(e) {}

        // 4. Hook Location.prototype.assign and replace
        try {
          if (window.Location && window.Location.prototype) {
            window.Location.prototype.assign = function(url) {
              window.parent.postMessage({
                type: 'WEBP2P_NAVIGATE',
                href: String(url),
                basePath: CURRENT_PATH
              }, '*');
            };
            window.Location.prototype.replace = function(url) {
              window.parent.postMessage({
                type: 'WEBP2P_NAVIGATE',
                href: String(url),
                basePath: CURRENT_PATH
              }, '*');
            };
          }
        } catch(e) {}

        // 5. Patch URLSearchParams so new URLSearchParams(window.location.search) or new URLSearchParams()
        // immediately contains all URL parameters
        try {
          const OrigURLSearchParams = window.URLSearchParams;
          window.URLSearchParams = function(init) {
            if ((init === undefined || init === '' || init === window.location.search) && CURRENT_SEARCH) {
              return new OrigURLSearchParams(CURRENT_SEARCH);
            }
            return new OrigURLSearchParams(init);
          };
          window.URLSearchParams.prototype = OrigURLSearchParams.prototype;
          window.URLSearchParams.toString = function() { return OrigURLSearchParams.toString(); };
        } catch(e) {}

        // 6. Intercept internal <a> link clicks
        try {
          document.addEventListener('click', function(e) {
            const anchor = e.target.closest('a');
            if (!anchor) return;
            const href = anchor.getAttribute('href');
            if (!href) return;

            // Anchor links, hash links, or javascript
            if (href.startsWith('javascript:')) return;
            if (href === '#' || href.startsWith('#')) return;
            if (href.startsWith('http://') || href.startsWith('https://')) {
              // External link
              return;
            }

            e.preventDefault();
            window.parent.postMessage({
              type: 'WEBP2P_NAVIGATE',
              href: href,
              basePath: CURRENT_PATH
            }, '*');
          }, true);

          // Hook history pushState & replaceState for dynamic SPAs
          const origPush = history.pushState;
          history.pushState = function(state, title, url) {
            origPush.apply(history, arguments);
            if (url && !isInitializing) {
              window.parent.postMessage({
                type: 'WEBP2P_NAVIGATE',
                href: String(url),
                basePath: CURRENT_PATH,
                isPushState: true
              }, '*');
            }
          };

          const origReplace = history.replaceState;
          history.replaceState = function(state, title, url) {
            origReplace.apply(history, arguments);
            if (url && !isInitializing) {
              window.parent.postMessage({
                type: 'WEBP2P_NAVIGATE',
                href: String(url),
                basePath: CURRENT_PATH,
                isReplaceState: true
              }, '*');
            }
          };

          // Expose helper to inner scripts
          window.__WEBP2P__ = {
            pathname: CURRENT_PATH,
            search: CURRENT_SEARCH,
            hash: CURRENT_HASH
          };

          // Listen for parent messages (e.g. popstate / parameter updates)
          window.addEventListener('message', function(evt) {
            if (evt.data && evt.data.type === 'WEBP2P_UPDATE_PARAMS') {
              window.dispatchEvent(new PopStateEvent('popstate', { state: evt.data.params }));
            }
          });
        } catch(e) {
          console.error('WebP2P Bridge error:', e);
        }
      })();
    </script>
  `;

  // Inject bridge script at the very top of <head> so it runs before any user scripts
  if (htmlContent.includes('<head>')) {
    htmlContent = htmlContent.replace('<head>', `<head>${bridgeScript}`);
  } else if (htmlContent.includes('<head ')) {
    htmlContent = htmlContent.replace(/(<head[^>]*>)/i, `$1${bridgeScript}`);
  } else if (htmlContent.includes('</head>')) {
    htmlContent = htmlContent.replace('</head>', `${bridgeScript}</head>`);
  } else if (htmlContent.includes('<body>')) {
    htmlContent = htmlContent.replace('<body>', `<body>${bridgeScript}`);
  } else {
    htmlContent = `${bridgeScript}${htmlContent}`;
  }

  const finalBlob = new Blob([htmlContent], { type: 'text/html' });
  const htmlBlobUrl = URL.createObjectURL(finalBlob);
  activeBlobUrls.add(htmlBlobUrl);

  return {
    targetHtmlBlobUrl: htmlBlobUrl,
    normalizedPath: `/${lookupPath}`,
    search,
    hash,
    title,
  };
}
