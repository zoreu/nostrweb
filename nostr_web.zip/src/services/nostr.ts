import {
  generateSecretKey,
  getPublicKey,
  finalizeEvent,
  SimplePool,
} from 'nostr-tools';
import * as nip19 from 'nostr-tools/nip19';
import { NostrKeypair, NostrSiteMeta, RelayStatus } from '../types';

export const DEFAULT_RELAYS = [
  'wss://relay.damus.io',
  'wss://nos.lol',
  'wss://relay.nostr.band',
  'wss://nostr.mom',
  'wss://purplerelay.com',
];

export const KIND_WEB_SITE = 15128; // Kind 15128 for Nostr Static Sites / NIP-5A

// Global Nostr pool
export const nostrPool = new SimplePool();

/**
 * Generates a brand new random Nostr keypair.
 */
export function generateNewKeypair(): NostrKeypair {
  const sk = generateSecretKey();
  const privHex = bytesToHex(sk);
  const pubHex = getPublicKey(sk);
  const nsec = nip19.nsecEncode(sk);
  const npub = nip19.npubEncode(pubHex);

  return {
    pubkey: pubHex,
    privkey: privHex,
    npub,
    nsec,
    type: 'nsec',
  };
}

/**
 * Parses user input (nsec or hex) into a valid Nostr keypair.
 */
export function parsePrivateKey(input: string): NostrKeypair {
  const trimmed = input.trim();
  let privBytes: Uint8Array;

  if (trimmed.startsWith('nsec1')) {
    const decoded = nip19.decode(trimmed);
    if (decoded.type !== 'nsec') {
      throw new Error('Formato nsec inválido');
    }
    privBytes = decoded.data as Uint8Array;
  } else if (/^[0-9a-fA-F]{64}$/.test(trimmed)) {
    privBytes = hexToBytes(trimmed);
  } else {
    throw new Error('Chave privada inválida. Deve começar com nsec1... ou ser 64 caracteres hexadecimais.');
  }

  const privHex = bytesToHex(privBytes);
  const pubHex = getPublicKey(privBytes);
  const nsec = nip19.nsecEncode(privBytes);
  const npub = nip19.npubEncode(pubHex);

  return {
    pubkey: pubHex,
    privkey: privHex,
    npub,
    nsec,
    type: 'nsec',
  };
}

/**
 * Connects with NIP-07 browser extension (Alby, nos2x, etc.).
 */
export async function connectNip07(): Promise<NostrKeypair> {
  const nostr = (window as any).nostr;
  if (!nostr) {
    throw new Error('Nenhuma extensão Nostr (como Alby ou nos2x) foi detectada no seu navegador.');
  }

  const pubHex = await nostr.getPublicKey();
  const npub = nip19.npubEncode(pubHex);

  return {
    pubkey: pubHex,
    npub,
    type: 'nip07',
  };
}

/**
 * Signs an event using either private key or NIP-07 extension.
 */
export async function signNostrEvent(
  keypair: NostrKeypair,
  eventDraft: {
    kind: number;
    tags: string[][];
    content: string;
    created_at?: number;
  }
): Promise<any> {
  const fullDraft = {
    ...eventDraft,
    created_at: eventDraft.created_at || Math.floor(Date.now() / 1000),
  };

  if (keypair.type === 'nip07') {
    const nostr = (window as any).nostr;
    if (!nostr) throw new Error('Extensão Nostr desconectada.');
    return await nostr.signEvent(fullDraft);
  }

  if (!keypair.privkey) {
    throw new Error('Chave privada não encontrada para assinar o evento.');
  }

  const privBytes = hexToBytes(keypair.privkey);
  return finalizeEvent(fullDraft, privBytes);
}

/**
 * Encodes a site definition as an naddr pointer (NIP-19).
 */
export function encodeSiteNaddr(pubkey: string, dTag: string, relays: string[] = []): string {
  return nip19.naddrEncode({
    kind: KIND_WEB_SITE,
    pubkey,
    identifier: dTag,
    relays: relays.slice(0, 3),
  });
}

/**
 * Parses a site metadata object from a Kind 15128 event.
 */
export function parseSiteEvent(event: any, relays: string[] = DEFAULT_RELAYS): NostrSiteMeta {
  const dTag = event.tags?.find((t: string[]) => t[0] === 'd')?.[1] || 'root';
  const url = event.tags?.find((t: string[]) => t[0] === 'url')?.[1] || '';
  const sha256 = event.tags?.find((t: string[]) => t[0] === 'x')?.[1] || '';
  const title =
    event.tags?.find((t: string[]) => t[0] === 'title')?.[1] ||
    event.tags?.find((t: string[]) => t[0] === 'name')?.[1] ||
    dTag;
  const description =
    event.tags?.find((t: string[]) => t[0] === 'description')?.[1] ||
    event.tags?.find((t: string[]) => t[0] === 'summary')?.[1] ||
    event.content ||
    '';
  const sizeStr = event.tags?.find((t: string[]) => t[0] === 'size')?.[1] || '0';
  const entrypoint =
    event.tags?.find((t: string[]) => t[0] === 'entrypoint')?.[1] || 'index.html';
  const fallbackUrl = event.tags?.find((t: string[]) => t[0] === 'fallback')?.[1];
  const nip = event.tags?.find((t: string[]) => t[0] === 'nip')?.[1] || '5A';

  const npub = nip19.npubEncode(event.pubkey);
  const naddr = encodeSiteNaddr(event.pubkey, dTag, relays);

  return {
    id: event.id,
    pubkey: event.pubkey,
    npub,
    dTag,
    title,
    description,
    url,
    sha256,
    size: parseInt(sizeStr, 10) || 0,
    entrypoint,
    publishedAt: event.created_at,
    relays,
    fallbackUrl,
    naddr,
    nip,
  };
}

/**
 * Publishes a Kind 15128 event to specified relays.
 */
export async function publishSiteEvent(
  keypair: NostrKeypair,
  siteData: {
    dTag: string;
    title: string;
    description: string;
    blossomUrl: string;
    sha256: string;
    fileSize: number;
    entrypoint?: string;
    fallbackUrl?: string;
  },
  relays: string[] = DEFAULT_RELAYS
): Promise<{ event: any; successRelays: string[]; failedRelays: string[]; naddr: string }> {
  const cleanDTag = siteData.dTag.trim() || 'root';
  const entrypoint = siteData.entrypoint?.trim() || 'index.html';

  const tags: string[][] = [
    ['d', cleanDTag],
    ['title', siteData.title],
    ['description', siteData.description],
    ['url', siteData.blossomUrl],
    ['x', siteData.sha256],
    ['m', 'application/zip'],
    ['size', String(siteData.fileSize)],
    ['entrypoint', entrypoint],
    ['nip', '5A'],
    ['published_at', String(Math.floor(Date.now() / 1000))],
  ];

  if (siteData.fallbackUrl) {
    tags.push(['fallback', siteData.fallbackUrl]);
  }

  const eventDraft = {
    kind: KIND_WEB_SITE,
    created_at: Math.floor(Date.now() / 1000),
    tags,
    content: siteData.description,
  };

  const signedEvent = await signNostrEvent(keypair, eventDraft);

  const successRelays: string[] = [];
  const failedRelays: string[] = [];

  const promises = relays.map(async (relay) => {
    try {
      await Promise.race([
        nostrPool.publish([relay], signedEvent),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Timeout')), 5000)
        ),
      ]);
      successRelays.push(relay);
    } catch {
      failedRelays.push(relay);
    }
  });

  await Promise.allSettled(promises);

  const naddr = encodeSiteNaddr(keypair.pubkey, cleanDTag, relays);

  return {
    event: signedEvent,
    successRelays,
    failedRelays,
    naddr,
  };
}

/**
 * Resolves a site address string. Supports:
 * - naddr1...
 * - nostr:naddr1...
 * - npub1.../dTag
 * - hexPubkey/dTag
 * - note1... / nevent1...
 */
export async function fetchSiteEvent(
  addressInput: string,
  relays: string[] = DEFAULT_RELAYS
): Promise<NostrSiteMeta | null> {
  const clean = addressInput.replace(/^nostr:/, '').trim();

  // 1. Is it naddr?
  if (clean.startsWith('naddr1')) {
    try {
      const decoded = nip19.decode(clean);
      if (decoded.type === 'naddr') {
        const { pubkey, identifier, relays: customRelays } = decoded.data;
        const allRelays = Array.from(new Set([...(customRelays || []), ...relays]));
        const filter = {
          kinds: [KIND_WEB_SITE],
          authors: [pubkey],
          '#d': [identifier],
        };
        const event = await nostrPool.get(allRelays, filter);
        if (event) {
          return parseSiteEvent(event, allRelays);
        }
      }
    } catch (err) {
      console.warn('naddr decode/fetch error:', err);
    }
  }

  // 2. Is it npub/... or pubkey/... format?
  if (clean.includes('/')) {
    const [pubPart, ...dParts] = clean.split('/');
    const dTag = dParts.join('/') || 'root';
    let pubHex = '';

    if (pubPart.startsWith('npub1')) {
      try {
        const decoded = nip19.decode(pubPart);
        if (decoded.type === 'npub') {
          pubHex = decoded.data as string;
        }
      } catch (err) {
        console.warn('Invalid npub in address:', err);
      }
    } else if (/^[0-9a-fA-F]{64}$/.test(pubPart)) {
      pubHex = pubPart;
    }

    if (pubHex) {
      const filter = {
        kinds: [KIND_WEB_SITE],
        authors: [pubHex],
        '#d': [dTag],
      };
      const event = await nostrPool.get(relays, filter);
      if (event) {
        return parseSiteEvent(event, relays);
      }
    }
  }

  // 3. Is it nevent or note?
  if (clean.startsWith('nevent1') || clean.startsWith('note1')) {
    try {
      const decoded = nip19.decode(clean);
      let eventId = '';
      let eventRelays = relays;
      if (decoded.type === 'nevent') {
        eventId = decoded.data.id;
        if (decoded.data.relays?.length) {
          eventRelays = Array.from(new Set([...decoded.data.relays, ...relays]));
        }
      } else if (decoded.type === 'note') {
        eventId = decoded.data as string;
      }

      if (eventId) {
        const event = await nostrPool.get(eventRelays, { ids: [eventId] });
        if (event) {
          return parseSiteEvent(event, eventRelays);
        }
      }
    } catch (err) {
      console.warn('nevent/note fetch error:', err);
    }
  }

  // 4. Try direct query by d-tag or hex pubkey
  if (/^[0-9a-fA-F]{64}$/.test(clean)) {
    const event = await nostrPool.get(relays, { ids: [clean] });
    if (event) {
      return parseSiteEvent(event, relays);
    }
  }

  return null;
}

/**
 * Fetches all Kind 15128 sites published by a specific author pubkey.
 */
export async function fetchUserPublishedSites(
  pubkey: string,
  relays: string[] = DEFAULT_RELAYS
): Promise<NostrSiteMeta[]> {
  try {
    const events = await nostrPool.querySync(relays, {
      kinds: [KIND_WEB_SITE],
      authors: [pubkey],
    });

    const map = new Map<string, NostrSiteMeta>();
    for (const ev of events) {
      const site = parseSiteEvent(ev, relays);
      const existing = map.get(site.dTag);
      if (!existing || site.publishedAt > existing.publishedAt) {
        map.set(site.dTag, site);
      }
    }

    return Array.from(map.values()).sort((a, b) => b.publishedAt - a.publishedAt);
  } catch (err) {
    console.warn('Error fetching user published sites:', err);
    return [];
  }
}

/**
 * Discovers public Kind 15128 sites on relays.
 */
export async function discoverPublicSites(
  relays: string[] = DEFAULT_RELAYS
): Promise<NostrSiteMeta[]> {
  try {
    const events = await nostrPool.querySync(relays, {
      kinds: [KIND_WEB_SITE],
      limit: 25,
    });

    const parsed: NostrSiteMeta[] = [];
    const seen = new Set<string>();

    for (const ev of events) {
      const site = parseSiteEvent(ev, relays);
      const key = `${site.pubkey}:${site.dTag}`;
      if (!seen.has(key) && site.url) {
        seen.add(key);
        parsed.push(site);
      }
    }

    return parsed.sort((a, b) => b.publishedAt - a.publishedAt);
  } catch (err) {
    console.warn('Could not discover public sites:', err);
    return [];
  }
}

/**
 * Checks connection status of relays.
 */
export async function testRelaysStatus(relays: string[] = DEFAULT_RELAYS): Promise<RelayStatus[]> {
  const statuses: RelayStatus[] = [];

  const promises = relays.map(async (url) => {
    const start = performance.now();
    try {
      const ws = new WebSocket(url);
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          ws.close();
          reject(new Error('Timeout'));
        }, 3500);

        ws.onopen = () => {
          clearTimeout(timeout);
          ws.close();
          resolve();
        };
        ws.onerror = () => {
          clearTimeout(timeout);
          reject(new Error('Connection failed'));
        };
      });

      const ping = Math.round(performance.now() - start);
      statuses.push({ url, connected: true, ping });
    } catch (e: any) {
      statuses.push({ url, connected: false, error: e.message || 'Falha de conexão' });
    }
  });

  await Promise.allSettled(promises);
  return statuses;
}

// Utility functions for byte conversion
function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2 !== 0) throw new Error('Hex length must be even');
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}
