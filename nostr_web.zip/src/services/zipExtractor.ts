import JSZip from 'jszip';
import { SiteFile } from '../types';

export function getMimeType(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  switch (ext) {
    case 'html':
    case 'htm':
      return 'text/html';
    case 'css':
      return 'text/css';
    case 'js':
    case 'mjs':
      return 'application/javascript';
    case 'json':
      return 'application/json';
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'gif':
      return 'image/gif';
    case 'svg':
      return 'image/svg+xml';
    case 'webp':
      return 'image/webp';
    case 'ico':
      return 'image/x-icon';
    case 'woff':
      return 'font/woff';
    case 'woff2':
      return 'font/woff2';
    case 'ttf':
      return 'font/ttf';
    case 'txt':
    case 'md':
      return 'text/plain';
    case 'xml':
      return 'application/xml';
    case 'wasm':
      return 'application/wasm';
    default:
      return 'application/octet-stream';
  }
}

export function isTextMime(mime: string): boolean {
  return (
    mime.startsWith('text/') ||
    mime.includes('javascript') ||
    mime.includes('json') ||
    mime.includes('xml') ||
    mime.includes('svg')
  );
}

export async function extractZipToFiles(
  zipBuffer: ArrayBuffer | Blob
): Promise<Record<string, SiteFile>> {
  const zip = new JSZip();
  const loaded = await zip.loadAsync(zipBuffer);
  const files: Record<string, SiteFile> = {};

  // Check if all files are wrapped in a single root directory (e.g. "dist/" or "build/")
  const fileNames = Object.keys(loaded.files).filter(
    (name) => !loaded.files[name].dir
  );
  let commonPrefix = '';
  if (fileNames.length > 0) {
    const firstSlash = fileNames[0].indexOf('/');
    if (firstSlash > 0) {
      const candidate = fileNames[0].substring(0, firstSlash + 1);
      const allStartWith = fileNames.every((f) => f.startsWith(candidate));
      // Only strip if index.html is inside this prefix
      if (allStartWith && fileNames.some((f) => f === `${candidate}index.html`)) {
        commonPrefix = candidate;
      }
    }
  }

  for (const [rawPath, entry] of Object.entries(loaded.files)) {
    if (entry.dir) continue;

    let cleanPath = rawPath.replace(/^\.?\//, '');
    if (commonPrefix && cleanPath.startsWith(commonPrefix)) {
      cleanPath = cleanPath.slice(commonPrefix.length);
    }
    cleanPath = cleanPath.replace(/^\/+/, '');

    const mime = getMimeType(cleanPath);
    const isText = isTextMime(mime);

    if (isText) {
      const textContent = await entry.async('string');
      files[cleanPath] = {
        path: cleanPath,
        content: textContent,
        mimeType: mime,
        isText: true,
        size: textContent.length,
      };
    } else {
      const arrayBuffer = await entry.async('arraybuffer');
      files[cleanPath] = {
        path: cleanPath,
        content: arrayBuffer,
        mimeType: mime,
        isText: false,
        size: arrayBuffer.byteLength,
      };
    }
  }

  return files;
}

/**
 * Generates an interactive starter site package with its own completely distinct style,
 * distinct background, independent typography, and dynamic URL navigation.
 */
export async function createSampleSiteZip(
  title: string,
  dTag: string
): Promise<{ blob: Blob; fileName: string }> {
  const zip = new JSZip();

  const css = `
/* Estilos 100% próprios e independentes do site */
:root {
  --bg-page: #f8fafc;
  --bg-card: #ffffff;
  --text-main: #0f172a;
  --text-muted: #64748b;
  --border: #e2e8f0;
  --primary: #0284c7;
  --primary-hover: #0369a1;
  --emerald: #059669;
  --badge-bg: #e0f2fe;
  --badge-text: #0369a1;
}

/* Modo escuro próprio do site se selecionado via parâmetro ?tema=escuro */
body.tema-escuro {
  --bg-page: #18181b;
  --bg-card: #27272a;
  --text-main: #fafafa;
  --text-muted: #a1a1aa;
  --border: #3f3f46;
  --primary: #38bdf8;
  --primary-hover: #7dd3fc;
  --emerald: #34d399;
  --badge-bg: #032e4d;
  --badge-text: #7dd3fc;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
  background-color: var(--bg-page);
  color: var(--text-main);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  line-height: 1.6;
  min-height: 100vh;
}

.header {
  background: var(--bg-card);
  border-bottom: 1px solid var(--border);
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.logo {
  font-weight: 800;
  font-size: 1.2rem;
  text-decoration: none;
  color: var(--text-main);
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.nav {
  display: flex;
  gap: 1.25rem;
  align-items: center;
}

.nav a {
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 600;
  transition: color 0.15s;
}

.nav a:hover, .nav a.active {
  color: var(--primary);
}

.container {
  max-width: 920px;
  margin: 0 auto;
  padding: 3rem 1.5rem;
}

.hero {
  text-align: center;
  margin-bottom: 3rem;
}

.badge {
  display: inline-block;
  background: var(--badge-bg);
  color: var(--badge-text);
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.05em;
  padding: 0.3rem 0.75rem;
  border-radius: 9999px;
  margin-bottom: 1rem;
}

h1 {
  font-size: 2.5rem;
  font-weight: 800;
  line-height: 1.2;
  margin-bottom: 0.75rem;
}

.subtitle {
  font-size: 1.15rem;
  color: var(--text-muted);
  max-width: 600px;
  margin: 0 auto 2rem auto;
}

.card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.75rem;
  box-shadow: 0 2px 6px rgba(0,0,0,0.03);
  margin-bottom: 1.5rem;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.5rem;
  margin-top: 1.5rem;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: var(--primary);
  color: #ffffff;
  padding: 0.65rem 1.25rem;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
  font-size: 0.9rem;
  border: none;
  cursor: pointer;
  transition: background 0.15s;
}

.btn:hover {
  background: var(--primary-hover);
}

.btn-outline {
  background: transparent;
  border: 1px solid var(--border);
  color: var(--text-main);
}

.btn-outline:hover {
  background: var(--border);
}

.params-inspector {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-left: 4px solid var(--primary);
  border-radius: 8px;
  padding: 1.25rem;
  margin-top: 1rem;
  font-family: monospace;
  font-size: 0.85rem;
}

.theme-selector {
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
}
`;

  const indexHtml = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <a href="index.html" class="logo">
      <span>🚀</span>
      <span>${title}</span>
    </a>
    <nav class="nav">
      <a href="index.html" class="active">Início</a>
      <a href="produtos.html?categoria=destaques">Página 2 (?query)</a>
      <a href="sobre.html?ref=navbar">Sobre</a>
    </nav>
  </header>

  <main class="container">
    <section class="hero">
      <span class="badge">Nostr Kind 15128 · NIP-5A · Blossom</span>
      <h1>${title}</h1>
      <p class="subtitle">Este site estático possui seu próprio design, plano de fundo e paleta de cores 100% independentes do navegador WebP2P.</p>
    </section>

    <!-- Theme and background demonstrator -->
    <div class="card">
      <h3 style="margin-bottom:0.5rem;">🎨 Estilo e Fundo Próprios do Site</h3>
      <p style="color:var(--text-muted); font-size:0.95rem;">
        O site define seu próprio <code>background-color</code> e não herda nenhum elemento escuro do WebP2P. Alterne o tema deste site via parâmetro de URL:
      </p>
      
      <div class="theme-selector">
        <a href="index.html?tema=claro" class="btn btn-outline">☀️ Tema Claro (?tema=claro)</a>
        <a href="index.html?tema=escuro" class="btn btn-outline">🌙 Tema Escuro (?tema=escuro)</a>
        <a href="produtos.html?categoria=software&filtro=p2p" class="btn">Testar Subpágina com Filtros &rarr;</a>
      </div>

      <div class="params-inspector">
        <div><strong>URL Recebida:</strong> <span id="current-url" style="color:var(--primary); font-weight:bold;">carregando...</span></div>
        <div><strong>Parâmetros Ativos:</strong> <span id="active-params">nenhum</span></div>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <h3>⚡ Kind 15128</h3>
        <p style="color:var(--text-muted); font-size:0.9rem; margin:0.5rem 0 1rem 0;">
          Identificador deste site no Nostr: <strong>${dTag}</strong>.
        </p>
        <a href="sobre.html?topico=identidade" class="btn btn-outline">Saiba mais</a>
      </div>
      <div class="card">
        <h3>🌸 Blossom Blobs</h3>
        <p style="color:var(--text-muted); font-size:0.9rem; margin:0.5rem 0 1rem 0;">
          Os arquivos deste pacote foram baixados diretamente de servidores Blossom.
        </p>
        <a href="sobre.html?topico=blossom" class="btn btn-outline">Como funciona</a>
      </div>
    </div>
  </main>

  <script src="script.js"></script>
</body>
</html>`;

  const produtosHtml = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Página de Demonstração - ${title}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <a href="index.html" class="logo">
      <span>🚀</span>
      <span>${title}</span>
    </a>
    <nav class="nav">
      <a href="index.html">Início</a>
      <a href="produtos.html" class="active">Página 2 (?query)</a>
      <a href="sobre.html">Sobre</a>
    </nav>
  </header>

  <main class="container">
    <div style="margin-bottom: 2rem;">
      <a href="index.html" style="color:var(--text-muted); text-decoration:none; font-size:0.9rem;">&larr; Voltar para Início</a>
      <h1 style="margin-top: 0.5rem;">Navegação Dinâmica com Parâmetros</h1>
      <p class="subtitle">Esta subpágina lê parâmetros da URL e atualiza o estado da página sem recarregar o navegador.</p>
    </div>

    <div class="card">
      <h3>Filtros Dinâmicos de Exemplo:</h3>
      <div style="display:flex; gap:0.5rem; margin-top: 1rem; flex-wrap:wrap;">
        <button onclick="setCategoria('todos')" class="btn btn-outline" id="btn-todos">Todos</button>
        <button onclick="setCategoria('p2p')" class="btn btn-outline" id="btn-p2p">P2P</button>
        <button onclick="setCategoria('nostr')" class="btn btn-outline" id="btn-nostr">Nostr</button>
        <button onclick="setCategoria('web')" class="btn btn-outline" id="btn-web">Web</button>
      </div>

      <div class="params-inspector" style="margin-top: 1.5rem;">
        <div><strong>URL Atual:</strong> <span id="current-url" style="color:var(--primary); font-weight:bold;">carregando...</span></div>
        <div><strong>Categoria Selecionada:</strong> <span id="category-display">todas</span></div>
      </div>
    </div>
  </main>

  <script src="script.js"></script>
</body>
</html>`;

  const sobreHtml = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sobre - ${title}</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="header">
    <a href="index.html" class="logo">
      <span>🚀</span>
      <span>${title}</span>
    </a>
    <nav class="nav">
      <a href="index.html">Início</a>
      <a href="produtos.html">Página 2 (?query)</a>
      <a href="sobre.html" class="active">Sobre</a>
    </nav>
  </header>

  <main class="container">
    <div style="margin-bottom: 2rem;">
      <a href="index.html" style="color:var(--text-muted); text-decoration:none; font-size:0.9rem;">&larr; Voltar para Início</a>
      <h1 style="margin-top: 0.5rem;">Sobre ${title}</h1>
      <p class="subtitle">Exemplo de website com isolamento completo de CSS e layout.</p>
    </div>

    <div class="card">
      <h3>Garantia de Isolamento de Estilos</h3>
      <p style="color:var(--text-muted); font-size:0.95rem; margin-top: 0.5rem; line-height:1.7;">
        O WebP2P executa o site dentro de um contexto isolado. Seu site tem total controle sobre suas próprias cores, fontes, fundos, imagens e scripts.
      </p>

      <div class="params-inspector" style="margin-top: 1.5rem;">
        <div><strong>URL Completa:</strong> <span id="current-url">carregando...</span></div>
      </div>
    </div>
  </main>

  <script src="script.js"></script>
</body>
</html>`;

  const scriptJs = `
function updateSiteInfo() {
  const currentUrlSpan = document.getElementById('current-url');
  const paramsSpan = document.getElementById('active-params');
  const categorySpan = document.getElementById('category-display');

  if (currentUrlSpan) {
    currentUrlSpan.textContent = window.location.pathname + window.location.search + window.location.hash;
  }

  const searchParams = new URLSearchParams(window.location.search);
  const entries = Array.from(searchParams.entries());

  if (paramsSpan) {
    if (entries.length === 0) {
      paramsSpan.textContent = 'Nenhum parâmetro';
    } else {
      paramsSpan.textContent = entries.map(([k, v]) => k + ' = "' + v + '"').join(', ');
    }
  }

  // Handle ?tema=escuro or ?tema=claro
  const tema = searchParams.get('tema');
  if (tema === 'escuro') {
    document.body.classList.add('tema-escuro');
  } else {
    document.body.classList.remove('tema-escuro');
  }

  // Handle ?categoria=...
  const cat = searchParams.get('categoria') || 'todos';
  if (categorySpan) {
    categorySpan.textContent = cat.toUpperCase();
  }

  ['todos', 'p2p', 'nostr', 'web'].forEach(name => {
    const btn = document.getElementById('btn-' + name);
    if (btn) {
      if (name === cat) {
        btn.style.background = 'var(--primary)';
        btn.style.color = '#ffffff';
      } else {
        btn.style.background = 'transparent';
        btn.style.color = 'var(--text-main)';
      }
    }
  });
}

function setCategoria(cat) {
  const url = new URL(window.location.href);
  if (cat === 'todos') {
    url.searchParams.delete('categoria');
  } else {
    url.searchParams.set('categoria', cat);
  }
  window.history.pushState({}, '', url.pathname + url.search + url.hash);
  updateSiteInfo();
}

window.addEventListener('popstate', updateSiteInfo);
window.addEventListener('DOMContentLoaded', updateSiteInfo);
updateSiteInfo();
`;

  zip.file('index.html', indexHtml);
  zip.file('produtos.html', produtosHtml);
  zip.file('sobre.html', sobreHtml);
  zip.file('style.css', css);
  zip.file('script.js', scriptJs);

  const blob = await zip.generateAsync({ type: 'blob' });
  const safeName = dTag.replace(/[^a-zA-Z0-9_-]/g, '_') || 'site';
  return { blob, fileName: `${safeName}.zip` };
}
