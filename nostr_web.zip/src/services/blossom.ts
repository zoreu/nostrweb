import { BlossomUploadResult } from '../types';

export const DEFAULT_BLOSSOM_SERVERS = [
  'https://blossom.primal.net',
  'https://nostr.download',
];

/**
 * Calculates SHA-256 hex string in browser using Web Crypto API.
 */
export async function computeSha256(data: ArrayBuffer | Blob): Promise<string> {
  const buffer = data instanceof Blob ? await data.arrayBuffer() : data;
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(digest));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Creates Blossom Authorization header value (Kind 24242).
 */
export function createBlossomAuthHeader(signedAuthEvent: any): string {
  const jsonStr = JSON.stringify(signedAuthEvent);
  return `Nostr ${btoa(unescape(encodeURIComponent(jsonStr)))}`;
}

/**
 * Fallback local blob store for zero-latency instant offline retrieval.
 */
const BLOB_CACHE_PREFIX = 'blossom_blob_';

export async function storeLocalBlob(sha256: string, buffer: ArrayBuffer): Promise<void> {
  try {
    const db = await openBlobDB();
    const tx = db.transaction('blobs', 'readwrite');
    tx.objectStore('blobs').put({ sha256, buffer, storedAt: Date.now() });
  } catch (err) {
    console.warn('Failed to store blob in local DB:', err);
  }
}

export async function getLocalBlob(sha256: string): Promise<ArrayBuffer | null> {
  try {
    const db = await openBlobDB();
    return new Promise((resolve) => {
      const tx = db.transaction('blobs', 'readonly');
      const req = tx.objectStore('blobs').get(sha256);
      req.onsuccess = () => resolve(req.result?.buffer || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

function openBlobDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('webp2p_blobs_db', 1);
    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('blobs')) {
        db.createObjectStore('blobs', { keyPath: 'sha256' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/**
 * Uploads a file (ZIP) to Blossom server with fallback and local backup.
 */
export async function uploadToBlossom(
  file: File | Blob,
  preferredServer: string,
  signAuthEvent?: (draft: any) => Promise<any>
): Promise<BlossomUploadResult> {
  const arrayBuffer = await file.arrayBuffer();
  const sha256 = await computeSha256(arrayBuffer);

  // Store in local IndexedDB blob store so it can be previewed immediately even before propagation
  await storeLocalBlob(sha256, arrayBuffer);

  const serversToTry = [
    preferredServer,
    ...DEFAULT_BLOSSOM_SERVERS.filter((s) => s !== preferredServer),
  ];

  let lastError: any = null;

  for (const serverUrl of serversToTry) {
    const cleanServer = serverUrl.replace(/\/+$/, '');
    try {
      const uploadEndpoint = `${cleanServer}/upload`;
      const headers: Record<string, string> = {
        'Content-Type': 'application/zip',
        'X-SHA-256': sha256,
      };

      if (signAuthEvent) {
        try {
          const authDraft = {
            kind: 24242,
            created_at: Math.floor(Date.now() / 1000),
            tags: [
              ['t', 'upload'],
              ['x', sha256],
              ['expiration', String(Math.floor(Date.now() / 1000) + 3600)],
            ],
            content: `Upload static site ${sha256}`,
          };
          const signed = await signAuthEvent(authDraft);
          headers['Authorization'] = createBlossomAuthHeader(signed);
        } catch (e) {
          console.warn('Blossom auth signing skipped/failed:', e);
        }
      }

      // Try PUT first (standard Blossom BUD-01), then fallback to POST
      let response: Response;
      try {
        response = await fetch(uploadEndpoint, {
          method: 'PUT',
          headers,
          body: arrayBuffer,
        });
      } catch {
        response = await fetch(uploadEndpoint, {
          method: 'POST',
          headers,
          body: arrayBuffer,
        });
      }

      if (response.ok) {
        let resultJson: any = null;
        try {
          resultJson = await response.json();
        } catch {
          // Some servers return text or 200 with URL
        }

        const returnedUrl =
          resultJson?.url || `${cleanServer}/${sha256}.zip`;

        // Asynchronously mirror the package to remaining servers for redundancy
        const remainingServers = serversToTry.filter((s) => s.replace(/\/+$/, '') !== cleanServer);
        for (const mirrorServer of remainingServers) {
          const mirrorClean = mirrorServer.replace(/\/+$/, '');
          fetch(`${mirrorClean}/upload`, {
            method: 'PUT',
            headers,
            body: arrayBuffer,
          }).catch(() => {});
        }

        return {
          url: returnedUrl,
          sha256,
          size: arrayBuffer.byteLength,
          server: cleanServer,
        };
      } else {
        const errorText = await response.text().catch(() => '');
        console.warn(`Blossom upload failed on ${cleanServer} (${response.status}):`, errorText);
        lastError = new Error(`HTTP ${response.status}: ${errorText || 'Erro no servidor'}`);
      }
    } catch (err: any) {
      console.warn(`Could not reach Blossom server ${cleanServer}:`, err);
      lastError = err;
    }
  }

  throw new Error(
    `Falha no upload para os servidores Blossom (${lastError?.message || 'Servidores inacessíveis'}). O arquivo não pôde ser publicado na rede pública.`
  );
}

/**
 * Downloads a zip blob from Blossom URL or mirrors with SHA-256 verification.
 */
export async function downloadFromBlossom(
  primaryUrl: string,
  expectedSha256?: string,
  fallbackUrls: string[] = []
): Promise<ArrayBuffer> {
  // 1. Check local blob DB first for instantaneous load
  if (expectedSha256) {
    const local = await getLocalBlob(expectedSha256);
    if (local) {
      return local;
    }
  }

  const urlsToTry = [
    primaryUrl,
    ...fallbackUrls,
  ];

  if (expectedSha256) {
    for (const server of DEFAULT_BLOSSOM_SERVERS) {
      urlsToTry.push(`${server}/${expectedSha256}`);
      urlsToTry.push(`${server}/${expectedSha256}.zip`);
    }
  }

  // Deduplicate URLs
  const uniqueUrls = Array.from(new Set(urlsToTry.filter(Boolean)));

  let lastError: any = null;
  for (const url of uniqueUrls) {
    try {
      const resp = await fetch(url, { method: 'GET' });
      if (resp.ok) {
        const buffer = await resp.arrayBuffer();
        if (expectedSha256) {
          const actualSha = await computeSha256(buffer);
          if (actualSha.toLowerCase() !== expectedSha256.toLowerCase()) {
            console.warn(`SHA256 mismatch for ${url}: got ${actualSha}, expected ${expectedSha256}`);
            continue;
          }
        }
        // Save to local cache
        if (expectedSha256) {
          await storeLocalBlob(expectedSha256, buffer);
        }
        return buffer;
      }
    } catch (err) {
      lastError = err;
    }
  }

  // If all fails, check local cache once more
  if (expectedSha256) {
    const local = await getLocalBlob(expectedSha256);
    if (local) return local;
  }

  throw new Error(`Falha ao baixar arquivo Blossom. Servidores inacessíveis: ${lastError?.message || 'Erro de rede'}`);
}
