import { CachedSiteBundle, NostrSiteMeta, SiteFile } from '../types';

const DB_NAME = 'webp2p_cache_db';
const DB_VERSION = 1;
const STORE_NAME = 'sites';
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'siteKey' });
        store.createIndex('cachedAt', 'cachedAt', { unique: false });
        store.createIndex('expiresAt', 'expiresAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getCachedSite(
  siteKey: string,
  ignoreTimeout = false
): Promise<{ bundle: CachedSiteBundle | null; isExpired: boolean }> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(siteKey);

      req.onsuccess = () => {
        const entry = req.result as CachedSiteBundle | undefined;
        if (!entry) {
          resolve({ bundle: null, isExpired: false });
          return;
        }

        const isExpired = Date.now() > entry.expiresAt;
        if (isExpired && !ignoreTimeout) {
          resolve({ bundle: null, isExpired: true });
        } else {
          resolve({ bundle: entry, isExpired });
        }
      };

      req.onerror = () => resolve({ bundle: null, isExpired: false });
    });
  } catch (err) {
    console.warn('IndexedDB read error:', err);
    return { bundle: null, isExpired: false };
  }
}

export async function saveCachedSite(
  siteKey: string,
  meta: NostrSiteMeta,
  files: Record<string, SiteFile>
): Promise<CachedSiteBundle> {
  const now = Date.now();
  const bundle: CachedSiteBundle = {
    siteKey,
    meta,
    files,
    cachedAt: now,
    expiresAt: now + CACHE_TTL_MS,
  };

  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(bundle);

      req.onsuccess = () => resolve(bundle);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IndexedDB write error:', err);
    return bundle;
  }
}

export async function deleteCachedSite(siteKey: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(siteKey);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('IndexedDB delete error:', err);
  }
}

export async function listCachedSites(): Promise<
  Array<{
    siteKey: string;
    title: string;
    description: string;
    cachedAt: number;
    expiresAt: number;
    isExpired: boolean;
    fileCount: number;
    totalSizeBytes: number;
    naddr: string;
  }>
> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();

      req.onsuccess = () => {
        const list = (req.result as CachedSiteBundle[]) || [];
        const now = Date.now();
        const mapped = list.map((item) => {
          let totalSize = 0;
          const files = item.files || {};
          for (const key in files) {
            totalSize += files[key].size || 0;
          }
          return {
            siteKey: item.siteKey,
            title: item.meta?.title || 'Sem título',
            description: item.meta?.description || '',
            cachedAt: item.cachedAt,
            expiresAt: item.expiresAt,
            isExpired: now > item.expiresAt,
            fileCount: Object.keys(files).length,
            totalSizeBytes: totalSize,
            naddr: item.meta?.naddr || '',
          };
        });
        resolve(mapped);
      };

      req.onerror = () => resolve([]);
    });
  } catch (err) {
    console.warn('IndexedDB list error:', err);
    return [];
  }
}

export async function clearExpiredCachedSites(): Promise<number> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();

      req.onsuccess = () => {
        const list = (req.result as CachedSiteBundle[]) || [];
        const now = Date.now();
        let deleted = 0;
        for (const item of list) {
          if (now > item.expiresAt) {
            store.delete(item.siteKey);
            deleted++;
          }
        }
        resolve(deleted);
      };

      req.onerror = () => resolve(0);
    });
  } catch {
    return 0;
  }
}
