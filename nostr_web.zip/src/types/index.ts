export interface NostrKeypair {
  pubkey: string; // hex
  privkey?: string; // hex
  npub: string;
  nsec?: string;
  type: 'nsec' | 'nip07' | 'readonly';
}

export interface NostrSiteMeta {
  id: string; // event id
  pubkey: string;
  npub: string;
  dTag: string; // identifier
  title: string;
  description: string;
  url: string; // blossom url
  sha256: string;
  size: number;
  entrypoint: string;
  publishedAt: number;
  relays: string[];
  fallbackUrl?: string;
  naddr: string;
  nip: string;
}

export interface SiteFile {
  path: string;
  content: ArrayBuffer | string;
  mimeType: string;
  isText: boolean;
  size: number;
}

export interface CachedSiteBundle {
  siteKey: string; // sha256 or pubkey:dTag
  meta: NostrSiteMeta;
  files: Record<string, SiteFile>;
  cachedAt: number;
  expiresAt: number; // cachedAt + 24 hours
}

export interface NavigationState {
  currentAddress: string; // full address, e.g. naddr.../path.html?param=value#hash
  rawSiteAddress: string; // naddr... or npub.../d-tag
  currentPath: string; // /index.html, /about.html
  searchParams: Record<string, string>;
  rawSearch: string; // ?param=value
  hash: string; // #section
  title: string;
}

export interface BlossomUploadResult {
  url: string;
  sha256: string;
  size: number;
  server: string;
}

export interface RelayStatus {
  url: string;
  connected: boolean;
  ping?: number;
  error?: string;
}
