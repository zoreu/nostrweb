import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  NostrKeypair,
  NostrSiteMeta,
  NavigationState,
  SiteFile,
} from './types';
import {
  parseWebp2pAddress,
  renderSiteToBlobUrl,
  revokeAllRuntimeBlobs,
  resolveRelativePath,
} from './services/runtime';
import {
  getCachedSite,
  saveCachedSite,
} from './services/cache';
import {
  fetchSiteEvent,
  generateNewKeypair,
} from './services/nostr';
import { downloadFromBlossom } from './services/blossom';
import { extractZipToFiles } from './services/zipExtractor';
import { SidebarModal } from './components/SidebarModal';
import { BrowserFrame } from './components/BrowserFrame';
import { NewKeyModal } from './components/NewKeyModal';

const STORAGE_KEY_AUTH = 'webp2p_saved_keypair';
const STORAGE_KEY_LAST_ADDR = 'webp2p_last_address';

export default function App() {
  // Sidebar visibility (can be toggled / hidden leaving only expand button)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Auth Keypair state
  const [keypair, setKeypair] = useState<NostrKeypair | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_AUTH);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [generatedKeyDraft, setGeneratedKeyDraft] = useState<NostrKeypair | null>(null);

  // Active files & site meta in memory
  const currentFilesRef = useRef<Record<string, SiteFile>>({});
  const [currentSiteMeta, setCurrentSiteMeta] = useState<NostrSiteMeta | null>(null);

  // Navigation History Stack
  const [historyStack, setHistoryStack] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Current Navigation State
  const [navState, setNavState] = useState<NavigationState>({
    currentAddress: '',
    rawSiteAddress: '',
    currentPath: '/index.html',
    searchParams: {},
    rawSearch: '',
    hash: '',
    title: 'Início',
  });
  const navStateRef = useRef(navState);
  navStateRef.current = navState;

  // Browser rendering state
  const [activeBlobUrl, setActiveBlobUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Cache metadata for active site
  const [cacheStatus, setCacheStatus] = useState<{
    isCached: boolean;
    cachedAt?: number;
    expiresAt?: number;
    isExpired?: boolean;
    fileCount?: number;
  }>({
    isCached: false,
  });

  // Save keypair changes
  const handleSetKeypair = (kp: NostrKeypair | null) => {
    setKeypair(kp);
    if (kp) {
      localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(kp));
    } else {
      localStorage.removeItem(STORAGE_KEY_AUTH);
    }
  };

  // Request new key generation
  const handleRequestCreateKey = () => {
    const newKp = generateNewKeypair();
    setGeneratedKeyDraft(newKp);
  };

  const handleConfirmNewKey = () => {
    if (generatedKeyDraft) {
      handleSetKeypair(generatedKeyDraft);
      setGeneratedKeyDraft(null);
    }
  };

  /**
   * Internal renderer for a resolved file bundle.
   */
  const renderCurrentView = useCallback(
    (
      files: Record<string, SiteFile>,
      path: string,
      search: string,
      hash: string,
      meta?: NostrSiteMeta
    ) => {
      try {
        const resolved = renderSiteToBlobUrl(files, path, search, hash, meta);
        setActiveBlobUrl(resolved.targetHtmlBlobUrl);
        setNavState((prev) => ({
          ...prev,
          currentPath: resolved.normalizedPath,
          search,
          hash,
          title: resolved.title,
        }));
        setErrorMessage(null);
      } catch (err: any) {
        setErrorMessage('Erro ao compilar documento HTML: ' + err.message);
      }
    },
    []
  );

  /**
   * Loads and renders a given WebP2P site address.
   */
  const loadAddress = useCallback(
    async (
      fullAddress: string,
      options: { forceBypassCache?: boolean; addToHistory?: boolean } = {}
    ) => {
      const { forceBypassCache = false, addToHistory = true } = options;

      const parsed = parseWebp2pAddress(fullAddress);
      setNavState((prev) => ({
        ...prev,
        currentAddress: fullAddress,
        rawSiteAddress: parsed.rawSiteAddress,
        currentPath: parsed.path,
        searchParams: parsed.searchParams,
        rawSearch: parsed.search,
        hash: parsed.hash,
      }));

      // Update history if requested
      if (addToHistory) {
        setHistoryStack((prev) => {
          const nextStack = prev.slice(0, historyIndex + 1);
          nextStack.push(fullAddress);
          return nextStack;
        });
        setHistoryIndex((prev) => prev + 1);
      }

      // Check if we already have this exact site loaded in memory
      // and only the subpath/query parameters changed!
      const isSameSiteInMemory =
        currentSiteMeta &&
        (currentSiteMeta.naddr === parsed.rawSiteAddress ||
          parsed.rawSiteAddress.includes(currentSiteMeta.dTag) ||
          currentSiteMeta.sha256 === parsed.rawSiteAddress);

      if (isSameSiteInMemory && Object.keys(currentFilesRef.current).length > 0 && !forceBypassCache) {
        renderCurrentView(
          currentFilesRef.current,
          parsed.path,
          parsed.search,
          parsed.hash,
          currentSiteMeta
        );
        return;
      }

      setIsLoading(true);
      setErrorMessage(null);

      try {
        // STEP 1: Check 24-hour IndexedDB Cache first
        setLoadingMessage('Verificando cache local (24h)...');
        const cached = await getCachedSite(parsed.rawSiteAddress, false);

        if (cached.bundle && !forceBypassCache) {
          // Instant load from cache!
          currentFilesRef.current = cached.bundle.files;
          setCurrentSiteMeta(cached.bundle.meta);
          setCacheStatus({
            isCached: true,
            cachedAt: cached.bundle.cachedAt,
            expiresAt: cached.bundle.expiresAt,
            isExpired: false,
            fileCount: Object.keys(cached.bundle.files).length,
          });

          renderCurrentView(
            cached.bundle.files,
            parsed.path,
            parsed.search,
            parsed.hash,
            cached.bundle.meta
          );
          setIsLoading(false);
          return;
        }

        // STEP 2: Cache miss or force-refresh: Fetch from Nostr relays
        setLoadingMessage('Consultando evento Kind 15128 nos relays Nostr...');
        const siteMeta = await fetchSiteEvent(parsed.rawSiteAddress);

        if (!siteMeta) {
          throw new Error(
            `Não foi possível localizar o site para o endereço: "${parsed.rawSiteAddress}". Verifique se o naddr ou pubkey/d-tag está correto.`
          );
        }

        setCurrentSiteMeta(siteMeta);

        // STEP 3: Download ZIP from Blossom
        setLoadingMessage(`Baixando pacote do Blossom (${siteMeta.url})...`);
        const zipBuffer = await downloadFromBlossom(
          siteMeta.url,
          siteMeta.sha256,
          siteMeta.fallbackUrl ? [siteMeta.fallbackUrl] : []
        );

        // STEP 4: Extract ZIP files in memory
        setLoadingMessage('Descompactando arquivos e montando sandbox...');
        const extractedFiles = await extractZipToFiles(zipBuffer);
        currentFilesRef.current = extractedFiles;

        // STEP 5: Save to local IndexedDB cache with 24-hour timeout
        const savedBundle = await saveCachedSite(
          parsed.rawSiteAddress,
          siteMeta,
          extractedFiles
        );
        // Also index under the naddr and sha256 for fast lookup
        await saveCachedSite(siteMeta.naddr, siteMeta, extractedFiles);

        setCacheStatus({
          isCached: true,
          cachedAt: savedBundle.cachedAt,
          expiresAt: savedBundle.expiresAt,
          isExpired: false,
          fileCount: Object.keys(extractedFiles).length,
        });

        // STEP 6: Render HTML
        renderCurrentView(
          extractedFiles,
          parsed.path,
          parsed.search,
          parsed.hash,
          siteMeta
        );
      } catch (err: any) {
        console.error('Site load error:', err);
        setErrorMessage(err.message || 'Erro ao carregar site');
      } finally {
        setIsLoading(false);
      }
    },
    [currentSiteMeta, historyIndex, renderCurrentView]
  );

  // Initial startup: clean start without any demo page
  useEffect(() => {
    const lastAddr = localStorage.getItem(STORAGE_KEY_LAST_ADDR);
    if (lastAddr && !lastAddr.includes('demo') && !lastAddr.includes('webp2p-portal')) {
      loadAddress(lastAddr, { addToHistory: true });
    } else {
      localStorage.removeItem(STORAGE_KEY_LAST_ADDR);
    }

    return () => {
      revokeAllRuntimeBlobs();
    };
  }, []);

  // Save last address to localStorage
  useEffect(() => {
    if (navState.currentAddress) {
      localStorage.setItem(STORAGE_KEY_LAST_ADDR, navState.currentAddress);
    }
  }, [navState.currentAddress]);

  // Back button handler
  const handleGoBack = () => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      const prevAddr = historyStack[prevIdx];
      setHistoryIndex(prevIdx);
      loadAddress(prevAddr, { addToHistory: false });
    }
  };

  // Forward button handler
  const handleGoForward = () => {
    if (historyIndex < historyStack.length - 1) {
      const nextIdx = historyIndex + 1;
      const nextAddr = historyStack[nextIdx];
      setHistoryIndex(nextIdx);
      loadAddress(nextAddr, { addToHistory: false });
    }
  };

  // Reload button handler (with option to force bypass 24h cache)
  const handleReload = (forceBypassCache = false) => {
    if (navState.currentAddress) {
      loadAddress(navState.currentAddress, {
        forceBypassCache,
        addToHistory: false,
      });
    }
  };

  // Address bar submission
  const handleNavigateAddress = (newAddress: string) => {
    loadAddress(newAddress, { addToHistory: true });
  };

  // Applying new search parameters dynamically
  const handleApplySearchParams = (newParams: Record<string, string>) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(newParams)) {
      if (k.trim()) sp.set(k.trim(), v);
    }
    const searchStr = sp.toString() ? `?${sp.toString()}` : '';
    const newFullAddress = `${navState.rawSiteAddress}${navState.currentPath}${searchStr}${navState.hash}`;
    loadAddress(newFullAddress, { addToHistory: true });
  };

  // Internal link navigation intercepted from the iframe bridge
  const handleIframeNavigate = useCallback((targetHref: string, isPushState = false) => {
    // Ignore pure hash anchors
    if (!targetHref || targetHref === '#' || targetHref.startsWith('#')) {
      return;
    }

    let targetPath = '';
    let targetSearch = '';
    let targetHash = '';

    // Handle absolute URLs (http, https, blob)
    if (targetHref.startsWith('http://') || targetHref.startsWith('https://') || targetHref.startsWith('blob:')) {
      try {
        const u = new URL(targetHref);
        targetSearch = u.search || '';
        targetHash = u.hash || '';
        if (u.pathname && u.pathname !== '/' && !u.pathname.startsWith('/blob:') && !/^[0-9a-fA-F-]{36}$/.test(u.pathname.replace(/^\//, ''))) {
          targetPath = u.pathname.startsWith('/') ? u.pathname : `/${u.pathname}`;
        } else {
          targetPath = navStateRef.current.currentPath;
        }
      } catch (e) {
        targetPath = navStateRef.current.currentPath;
      }
    } else {
      const hashIdx = targetHref.indexOf('#');
      let noHash = targetHref;
      if (hashIdx !== -1) {
        targetHash = targetHref.substring(hashIdx);
        noHash = targetHref.substring(0, hashIdx);
      }

      const searchIdx = noHash.indexOf('?');
      let pathPart = noHash;
      if (searchIdx !== -1) {
        targetSearch = noHash.substring(searchIdx);
        pathPart = noHash.substring(0, searchIdx);
      }

      if (pathPart) {
        targetPath = '/' + resolveRelativePath(navStateRef.current.currentPath, pathPart);
      } else {
        targetPath = navStateRef.current.currentPath;
      }
    }

    const newFullAddress = `${navStateRef.current.rawSiteAddress}${targetPath}${targetSearch}${targetHash}`;

    // Loop prevention: do not re-navigate if address has not changed
    if (newFullAddress === navStateRef.current.currentAddress) {
      return;
    }

    loadAddress(newFullAddress, { addToHistory: !isPushState });
  }, [loadAddress]);

  const canGoBack = historyIndex > 0;
  const canGoForward = historyIndex < historyStack.length - 1;

  return (
    <div className="relative w-screen h-screen overflow-hidden flex bg-slate-950 font-sans select-none">
      {/* Lateral Modal / Drawer */}
      <SidebarModal
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        navState={navState}
        canGoBack={canGoBack}
        canGoForward={canGoForward}
        onGoBack={handleGoBack}
        onGoForward={handleGoForward}
        onReload={handleReload}
        onNavigateAddress={handleNavigateAddress}
        onApplySearchParams={handleApplySearchParams}
        currentSiteMeta={currentSiteMeta}
        cacheStatus={cacheStatus}
        keypair={keypair}
        onSetKeypair={handleSetKeypair}
        onRequestCreateKey={handleRequestCreateKey}
        history={historyStack}
      />

      {/* Main Browser Viewport */}
      <BrowserFrame
        isSidebarOpen={isSidebarOpen}
        onOpenSidebar={() => setIsSidebarOpen(true)}
        blobUrl={activeBlobUrl}
        isLoading={isLoading}
        loadingMessage={loadingMessage}
        errorMessage={errorMessage}
        navState={navState}
        canGoBack={canGoBack}
        canGoForward={canGoForward}
        onGoBack={handleGoBack}
        onGoForward={handleGoForward}
        onReload={() => handleReload(false)}
        onNavigateAddress={handleNavigateAddress}
        onIframeNavigate={handleIframeNavigate}
        currentSiteMeta={currentSiteMeta}
        isCached={cacheStatus.isCached}
      />

      {/* New Nostr Key Generation Modal */}
      {generatedKeyDraft && (
        <NewKeyModal
          keypair={generatedKeyDraft}
          onConfirm={handleConfirmNewKey}
          onCancel={() => setGeneratedKeyDraft(null)}
        />
      )}
    </div>
  );
}
