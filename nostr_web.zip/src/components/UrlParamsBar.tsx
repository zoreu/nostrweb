import React, { useState } from 'react';
import { SlidersHorizontal, Plus, Trash2 } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface UrlParamsBarProps {
  currentParams: Record<string, string>;
  onApplyParams: (newParams: Record<string, string>) => void;
}

export const UrlParamsBar: React.FC<UrlParamsBarProps> = ({
  currentParams,
  onApplyParams,
}) => {
  const { t, locale } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [paramKey, setParamKey] = useState('');
  const [paramValue, setParamValue] = useState('');

  const entries = Object.entries(currentParams);

  const handleAddParam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paramKey.trim()) return;
    const updated = {
      ...currentParams,
      [paramKey.trim()]: paramValue.trim(),
    };
    onApplyParams(updated);
    setParamKey('');
    setParamValue('');
  };

  const handleRemoveParam = (key: string) => {
    const updated = { ...currentParams };
    delete updated[key];
    onApplyParams(updated);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-xs">
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1.5 text-slate-300 hover:text-slate-100 font-medium cursor-pointer"
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-violet-400" />
          <span>{t.urlParamsTitle}</span>
          <span className="text-[10px] text-slate-400">
            ({entries.length})
          </span>
        </button>

        {entries.length > 0 && (
          <span className="text-[10px] text-teal-400 font-mono">
            {entries.length} {entries.length > 1 ? t.urlParamsActives : t.urlParamsActive}
          </span>
        )}
      </div>

      {/* Chip preview of active parameters */}
      {entries.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-2">
          {entries.map(([k, v]) => (
            <span
              key={k}
              className="inline-flex items-center gap-1 bg-slate-950 border border-slate-700 text-slate-200 px-2 py-0.5 rounded text-[11px] font-mono"
            >
              <span className="text-violet-400">{k}</span>=
              <span className="text-amber-300">"{v}"</span>
              <button
                type="button"
                onClick={() => handleRemoveParam(k)}
                className="hover:text-red-400 ml-0.5 cursor-pointer"
                title={`${t.urlParamsRemoveTooltip} ${k}`}
              >
                <Trash2 className="w-2.5 h-2.5" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Expanded parameter editor */}
      {isOpen && (
        <div className="mt-3 pt-2.5 border-t border-slate-800 space-y-2">
          <form onSubmit={handleAddParam} className="flex items-center gap-1.5">
            <input
              type="text"
              placeholder={t.urlParamsKeyPlaceholder}
              value={paramKey}
              onChange={(e) => setParamKey(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 focus:border-violet-500 rounded px-2 py-1 text-xs text-slate-200 outline-none"
            />
            <span className="text-slate-500">=</span>
            <input
              type="text"
              placeholder={t.urlParamsValuePlaceholder}
              value={paramValue}
              onChange={(e) => setParamValue(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 focus:border-violet-500 rounded px-2 py-1 text-xs text-slate-200 outline-none"
            />
            <button
              type="submit"
              className="p-1 bg-violet-600 hover:bg-violet-500 text-white rounded cursor-pointer"
              title={t.urlParamsAddTooltip}
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Quick preset tests for dynamic parameters */}
          <div className="pt-1">
            <div className="text-[10px] text-slate-400 mb-1">{t.urlParamsPresetsLabel}</div>
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={() => onApplyParams({ ...currentParams, tag: 'nostr', lang: locale })}
                className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded cursor-pointer"
              >
                + ?tag=nostr&lang={locale}
              </button>
              <button
                type="button"
                onClick={() => onApplyParams({ ...currentParams, theme: 'dark', filter: 'active' })}
                className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded cursor-pointer"
              >
                + ?theme=dark
              </button>
              <button
                type="button"
                onClick={() => onApplyParams({})}
                className="text-[10px] bg-red-950/50 hover:bg-red-900/60 text-red-300 px-1.5 py-0.5 rounded cursor-pointer"
              >
                {t.urlParamsClearAll}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
