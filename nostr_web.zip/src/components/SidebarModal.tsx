import React, { useState, useEffect } from 'react';
import {
  Globe,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Key,
  UploadCloud,
  FileArchive,
  CheckCircle2,
  AlertCircle,
  ChevronLeft,
  PlusCircle,
  Clock,
  Radio,
  Copy,
  Check,
  Eye,
  EyeOff,
  Sparkles,
  RefreshCw,
  Zap,
} from 'lucide-react';
import {
  NostrKeypair,
  NostrSiteMeta,
  RelayStatus,
  NavigationState,
} from '../types';
import {
  DEFAULT_RELAYS,
  parsePrivateKey,
  connectNip07,
  publishSiteEvent,
  fetchUserPublishedSites,
  discoverPublicSites,
  testRelaysStatus,
  signNostrEvent,
} from '../services/nostr';
import {
  DEFAULT_BLOSSOM_SERVERS,
  uploadToBlossom,
} from '../services/blossom';
import { createSampleSiteZip } from '../services/zipExtractor';
import {
  listCachedSites,
  clearExpiredCachedSites,
  deleteCachedSite,
} from '../services/cache';
import { UrlParamsBar } from './UrlParamsBar';
import { useLanguage } from '../i18n/LanguageContext';
import { LanguageToggle } from './LanguageToggle';

interface SidebarModalProps {
  isOpen: boolean;
  onClose: () => void;
  // Browser navigation
  navState: NavigationState;
  canGoBack: boolean;
  canGoForward: boolean;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: (forceBypassCache?: boolean) => void;
  onNavigateAddress: (address: string) => void;
  onApplySearchParams: (newParams: Record<string, string>) => void;
  currentSiteMeta: NostrSiteMeta | null;
  cacheStatus: {
    isCached: boolean;
    cachedAt?: number;
    expiresAt?: number;
    isExpired?: boolean;
    fileCount?: number;
  };
  // Nostr Auth
  keypair: NostrKeypair | null;
  onSetKeypair: (kp: NostrKeypair | null) => void;
  onRequestCreateKey: () => void;
  // Recent history
  history: string[];
}

export const SidebarModal: React.FC<SidebarModalProps> = ({
  isOpen,
  onClose,
  navState,
  canGoBack,
  canGoForward,
  onGoBack,
  onGoForward,
  onReload,
  onNavigateAddress,
  onApplySearchParams,
  currentSiteMeta,
  cacheStatus,
  keypair,
  onSetKeypair,
  onRequestCreateKey,
  history,
}) => {
  const { t, locale } = useLanguage();

  // Tabs in sidebar
  const [activeTab, setActiveTab] = useState<'navegar' | 'publicar' | 'explorar' | 'conta' | 'relays'>('navegar');

  // Address bar input
  const [addressInput, setAddressInput] = useState(navState.currentAddress);
  useEffect(() => {
    setAddressInput(navState.currentAddress);
  }, [navState.currentAddress]);

  // Auth form
  const [nsecInput, setNsecInput] = useState('');
  const [showNsec, setShowNsec] = useState(false);
  const [authError, setAuthError] = useState('');
  const [copiedNpub, setCopiedNpub] = useState(false);

  // Publish Form
  const [publishDTag, setPublishDTag] = useState('');
  const [publishTitle, setPublishTitle] = useState('');
  const [publishDescription, setPublishDescription] = useState('');
  const [publishEntrypoint, setPublishEntrypoint] = useState('index.html');
  const [publishBlossomServer, setPublishBlossomServer] = useState(DEFAULT_BLOSSOM_SERVERS[0]);
  const [selectedZipFile, setSelectedZipFile] = useState<File | Blob | null>(null);
  const [selectedZipName, setSelectedZipName] = useState<string>('');
  const [isGeneratingSample, setIsGeneratingSample] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStep, setPublishStep] = useState<string>('');
  const [publishSuccessNaddr, setPublishSuccessNaddr] = useState<string>('');
  const [publishError, setPublishError] = useState<string>('');
  const [userPublishedSites, setUserPublishedSites] = useState<
    Array<{
      dTag: string;
      title: string;
      description?: string;
      naddr: string;
      sha256?: string;
      size?: number;
      publishedAt?: number;
    }>
  >([]);
  const [publishSubTab, setPublishSubTab] = useState<'novo' | 'meus_sites'>('novo');
  const [updatingSiteDTag, setUpdatingSiteDTag] = useState<string | null>(null);
  const [isSyncingMySites, setIsSyncingMySites] = useState(false);

  // Load published sites for connected account and sync from relays
  useEffect(() => {
    if (!keypair?.pubkey) {
      setUserPublishedSites([]);
      return;
    }

    const storageKey = `webp2p_my_sites_${keypair.pubkey}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setUserPublishedSites(JSON.parse(saved));
      }
    } catch {}

    // Query relays in background to discover any existing sites published with this key
    fetchUserPublishedSites(keypair.pubkey, DEFAULT_RELAYS)
      .then((sites) => {
        if (sites.length > 0) {
          const mapped = sites.map((s) => ({
            dTag: s.dTag,
            title: s.title,
            description: s.description,
            naddr: s.naddr,
            sha256: s.sha256,
            size: s.size,
            publishedAt: s.publishedAt,
          }));

          setUserPublishedSites((prev) => {
            const map = new Map<string, any>();
            mapped.forEach((item) => map.set(item.dTag, item));
            prev.forEach((item) => {
              if (!map.has(item.dTag)) map.set(item.dTag, item);
            });
            const merged = Array.from(map.values());
            try {
              localStorage.setItem(storageKey, JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }
      })
      .catch((err) => console.warn('Could not sync user published sites:', err));
  }, [keypair?.pubkey]);

  // Sync user sites from relays explicitly
  const handleSyncMySites = async () => {
    if (!keypair?.pubkey) return;
    setIsSyncingMySites(true);
    try {
      const sites = await fetchUserPublishedSites(keypair.pubkey, DEFAULT_RELAYS);
      const mapped = sites.map((s) => ({
        dTag: s.dTag,
        title: s.title,
        description: s.description,
        naddr: s.naddr,
        sha256: s.sha256,
        size: s.size,
        publishedAt: s.publishedAt,
      }));
      setUserPublishedSites(mapped);
      localStorage.setItem(`webp2p_my_sites_${keypair.pubkey}`, JSON.stringify(mapped));
    } catch (err) {
      console.warn('Sync error:', err);
    } finally {
      setIsSyncingMySites(false);
    }
  };

  const handleStartUpdateSite = (site: {
    dTag: string;
    title: string;
    description?: string;
  }) => {
    setPublishDTag(site.dTag);
    setPublishTitle(site.title);
    setPublishDescription(site.description || '');
    setUpdatingSiteDTag(site.dTag);
    setPublishSubTab('novo');
  };

  const handleCancelUpdateMode = () => {
    setUpdatingSiteDTag(null);
    setPublishDTag('');
    setPublishTitle('');
    setPublishDescription('');
  };

  // Relays and Cache info
  const [relayStatuses, setRelayStatuses] = useState<RelayStatus[]>([]);
  const [isTestingRelays, setIsTestingRelays] = useState(false);
  const [cachedSitesList, setCachedSitesList] = useState<any[]>([]);
  const [discoveredSites, setDiscoveredSites] = useState<NostrSiteMeta[]>([]);
  const [isDiscovering, setIsDiscovering] = useState(false);

  // Load cache list on tab open
  const loadCacheData = async () => {
    const list = await listCachedSites();
    setCachedSitesList(list);
  };

  useEffect(() => {
    if (isOpen) {
      loadCacheData();
    }
  }, [isOpen, activeTab]);

  // Handle address submit
  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (addressInput.trim()) {
      onNavigateAddress(addressInput.trim());
    }
  };

  // Connect via nsec
  const handleConnectNsec = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      const kp = parsePrivateKey(nsecInput);
      onSetKeypair(kp);
      setNsecInput('');
    } catch (err: any) {
      setAuthError(err.message || t.invalidNsecError);
    }
  };

  // Connect via NIP-07 extension
  const handleConnectNip07 = async () => {
    setAuthError('');
    try {
      const kp = await connectNip07();
      onSetKeypair(kp);
    } catch (err: any) {
      setAuthError(err.message || 'Extensão Nostr não encontrada');
    }
  };

  // Generate sample starter zip
  const handleGenerateSampleZip = async () => {
    setIsGeneratingSample(true);
    try {
      const title = publishTitle.trim() || (locale === 'pt' ? 'Meu Site WebP2P' : 'My WebP2P Site');
      const dTag = publishDTag.trim() || 'site-p2p';
      const { blob, fileName } = await createSampleSiteZip(title, dTag);
      setSelectedZipFile(blob);
      setSelectedZipName(fileName);
      if (!publishTitle) setPublishTitle(title);
      if (!publishDTag) setPublishDTag(dTag);
      if (!publishDescription) {
        setPublishDescription(
          locale === 'pt'
            ? 'Site estático descentralizado publicado com WebP2P via Nostr e Blossom.'
            : 'Decentralized static website published with WebP2P via Nostr and Blossom.'
        );
      }
    } catch (err: any) {
      alert('Error: ' + err.message);
    } finally {
      setIsGeneratingSample(false);
    }
  };

  // File upload input change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedZipFile(file);
      setSelectedZipName(file.name);
      if (!publishDTag) {
        const autoDTag = file.name.replace(/\.[^/.]+$/, '').toLowerCase().replace(/[^a-z0-9_-]/g, '-');
        setPublishDTag(autoDTag);
      }
    }
  };

  // Publish Site (Kind 15128 & NIP-5A)
  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keypair) {
      setPublishError(t.requireAuthError);
      setActiveTab('conta');
      return;
    }
    if (!selectedZipFile) {
      setPublishError(t.requireZipError);
      return;
    }
    if (!publishDTag.trim()) {
      setPublishError(t.requireDTagError);
      return;
    }

    setIsPublishing(true);
    setPublishError('');
    setPublishSuccessNaddr('');

    try {
      // Step 1: Uploading to Blossom with BUD-01 signed authentication
      setPublishStep(t.step1Uploading);
      const uploadResult = await uploadToBlossom(
        selectedZipFile,
        publishBlossomServer,
        (draft) => signNostrEvent(keypair, draft)
      );

      // Step 2: Signing Kind 15128 (NIP-5A)
      setPublishStep(t.step2Signing);
      const publishResult = await publishSiteEvent(
        keypair,
        {
          dTag: publishDTag.trim(),
          title: publishTitle.trim() || publishDTag.trim(),
          description: publishDescription.trim(),
          blossomUrl: uploadResult.url,
          sha256: uploadResult.sha256,
          fileSize: uploadResult.size,
          entrypoint: publishEntrypoint.trim() || 'index.html',
        },
        DEFAULT_RELAYS
      );

      // Step 3: Broadcasted
      setPublishStep(t.step3Broadcasting);
      setPublishSuccessNaddr(publishResult.naddr);

      // Save to user published list
      const publishedSiteObj = {
        dTag: publishDTag.trim(),
        title: publishTitle.trim() || publishDTag.trim(),
        description: publishDescription.trim(),
        naddr: publishResult.naddr,
        sha256: uploadResult.sha256,
        size: uploadResult.size,
        publishedAt: Math.floor(Date.now() / 1000),
      };

      setUserPublishedSites((prev) => {
        const filtered = prev.filter((p) => p.dTag !== publishDTag.trim());
        const updated = [publishedSiteObj, ...filtered];
        if (keypair?.pubkey) {
          try {
            localStorage.setItem(`webp2p_my_sites_${keypair.pubkey}`, JSON.stringify(updated));
          } catch {}
        }
        return updated;
      });

      // Clear update mode on success
      setUpdatingSiteDTag(null);

      loadCacheData();
    } catch (err: any) {
      console.error('Publish error:', err);
      setPublishError(err.message || 'Falha na publicação do site');
    } finally {
      setIsPublishing(false);
    }
  };

  // Test relays
  const handleTestRelays = async () => {
    setIsTestingRelays(true);
    const results = await testRelaysStatus(DEFAULT_RELAYS);
    setRelayStatuses(results);
    setIsTestingRelays(false);
  };

  // Discover public sites
  const handleDiscoverSites = async () => {
    setIsDiscovering(true);
    const sites = await discoverPublicSites(DEFAULT_RELAYS);
    setDiscoveredSites(sites);
    setIsDiscovering(false);
  };

  // Format cache expiration
  const formatExpiration = (expiresAt?: number) => {
    if (!expiresAt) return null;
    const diffMs = expiresAt - Date.now();
    if (diffMs <= 0) return t.cacheExpired;
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m ${t.cacheRemaining}`;
  };

  if (!isOpen) return null;

  return (
    <aside className="fixed inset-y-0 left-0 z-40 w-full sm:w-[480px] bg-slate-950/95 backdrop-blur-xl border-r border-slate-800/80 shadow-2xl flex flex-col text-slate-100 transition-all duration-300">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/50">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-violet-500/20 text-white font-bold">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-bold text-slate-100 text-sm tracking-tight">{t.appTitle}</h2>
              <span className="text-[10px] text-violet-400 font-mono">Kind 15128 · NIP-5A</span>
            </div>
            <p className="text-[11px] text-slate-400">{t.appSubtitle}</p>
          </div>
        </div>

        {/* Language switch & Hide Button */}
        <div className="flex items-center gap-2">
          <LanguageToggle compact={false} />
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800/70 rounded-lg transition-colors cursor-pointer flex items-center gap-1 text-xs"
            title={t.hidePanel}
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">{t.hidePanel}</span>
          </button>
        </div>
      </div>

      {/* Navigation Toolbar (Address & Controls) */}
      <div className="p-3.5 bg-slate-900/40 border-b border-slate-800/80 space-y-2.5">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={!canGoBack}
            onClick={onGoBack}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800/80 text-slate-200 transition-colors cursor-pointer"
            title={t.backTooltip}
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            disabled={!canGoForward}
            onClick={onGoForward}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800/80 text-slate-200 transition-colors cursor-pointer"
            title={t.forwardTooltip}
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onReload(false)}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
            title={t.reloadTooltip}
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Address input */}
          <form onSubmit={handleAddressSubmit} className="flex-1 flex items-center gap-1">
            <div className="relative flex-1">
              <Globe className="w-3.5 h-3.5 text-violet-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder={t.addressPlaceholder}
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg pl-8 pr-2 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
            >
              {t.goBtn}
            </button>
          </form>
        </div>

        {/* Dynamic URL query parameters bar */}
        <UrlParamsBar
          currentParams={navState.searchParams}
          onApplyParams={onApplySearchParams}
        />

        {/* Local Cache Status Bar (with 24h timeout info & force refresh) */}
        <div className="flex items-center justify-between text-[11px] px-2.5 py-1.5 bg-slate-900/60 border border-slate-800/70 rounded-lg">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Clock className="w-3.5 h-3.5 text-teal-400" />
            <span>
              {cacheStatus.isCached ? (
                <>
                  <span className="text-teal-400 font-medium">{t.cache24hActive} </span>
                  <span>{formatExpiration(cacheStatus.expiresAt)}</span>
                </>
              ) : (
                <span className="text-slate-500">{t.cacheNoSaved}</span>
              )}
            </span>
          </div>

          <button
            type="button"
            onClick={() => onReload(true)}
            className="text-[10px] text-violet-400 hover:text-violet-300 font-medium flex items-center gap-1 cursor-pointer"
            title={t.forceRefreshTooltip}
          >
            <RefreshCw className="w-2.5 h-2.5" />
            {t.forceRefresh}
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-slate-800/80 bg-slate-900/30 text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('navegar')}
          className={`flex-1 py-2.5 text-center font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'navegar'
              ? 'border-violet-500 text-violet-400 bg-violet-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.tabBrowse}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('publicar')}
          className={`flex-1 py-2.5 text-center font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'publicar'
              ? 'border-violet-500 text-violet-400 bg-violet-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.tabPublish}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('explorar')}
          className={`flex-1 py-2.5 text-center font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'explorar'
              ? 'border-violet-500 text-violet-400 bg-violet-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.tabExplore}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('conta')}
          className={`flex-1 py-2.5 text-center font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'conta'
              ? 'border-violet-500 text-violet-400 bg-violet-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {keypair ? t.tabIdentity : t.tabConnect}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('relays')}
          className={`flex-1 py-2.5 text-center font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'relays'
              ? 'border-violet-500 text-violet-400 bg-violet-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.tabRelays}
        </button>
      </div>

      {/* Main Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {/* TAB 1: ACESSAR & NAVEGAR */}
        {activeTab === 'navegar' && (
          <div className="space-y-4">
            {currentSiteMeta ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-teal-400 uppercase tracking-wider font-semibold">
                    {t.siteLoadedBadge}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    d-tag: {currentSiteMeta.dTag}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-slate-100">{currentSiteMeta.title}</h3>
                {currentSiteMeta.description && (
                  <p className="text-slate-400 text-xs leading-relaxed">
                    {currentSiteMeta.description}
                  </p>
                )}

                <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">{t.authorLabel}</span>
                    <span className="font-mono text-slate-300 truncate block">
                      {currentSiteMeta.npub.slice(0, 14)}...
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">{t.blossomHashLabel}</span>
                    <span className="font-mono text-slate-300 truncate block">
                      {currentSiteMeta.sha256.slice(0, 12)}...
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(currentSiteMeta.naddr);
                      alert(t.naddrCopiedNotice);
                    }}
                    className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-center font-medium cursor-pointer"
                  >
                    {t.copyNaddrBtn}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPublishDTag(currentSiteMeta.dTag);
                      setPublishTitle(currentSiteMeta.title);
                      setPublishDescription(currentSiteMeta.description);
                      setActiveTab('publicar');
                    }}
                    className="flex-1 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-center font-medium cursor-pointer"
                  >
                    {t.updateThisSiteBtn}
                  </button>
                </div>
              </div>
            ) : null}

            {/* Guide to access Nostr sites */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
              <span className="font-semibold text-slate-200 block text-xs">
                {t.welcomeFormatsTitle}
              </span>
              <ul className="space-y-1.5 text-[11px] text-slate-400">
                <li className="flex items-start gap-1.5">
                  <span className="text-violet-400 font-mono shrink-0">1.</span>
                  <span>
                    <strong className="text-slate-300 font-mono">naddr1...</strong> — {t.formatNaddrDesc}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-teal-400 font-mono shrink-0">2.</span>
                  <span>
                    <strong className="text-slate-300 font-mono">npub1.../d-tag</strong> — {t.formatNpubDesc}
                  </span>
                </li>
                <li className="flex items-start gap-1.5">
                  <span className="text-amber-400 font-mono shrink-0">3.</span>
                  <span>
                    <strong className="text-slate-300 font-mono">/page.html?query=1</strong> — {t.formatPathDesc}
                  </span>
                </li>
              </ul>
            </div>

            {/* Recent History */}
            {history.length > 0 && (
              <div className="pt-2">
                <span className="font-semibold text-slate-300 text-xs block mb-2">
                  {t.recentHistoryLabel}
                </span>
                <div className="space-y-1">
                  {history.slice(-5).reverse().map((addr, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onNavigateAddress(addr)}
                      className="w-full text-left px-2.5 py-1.5 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-slate-300 text-[11px] font-mono truncate cursor-pointer"
                    >
                      {addr}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PUBLICAR & ATUALIZAR (.ZIP, KIND 15128, NIP-5A) */}
        {activeTab === 'publicar' && (
          <div className="space-y-3.5">
            {/* Sub-tab navigation: New Site vs My Published Sites */}
            <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-[11px]">
              <button
                type="button"
                onClick={() => setPublishSubTab('novo')}
                className={`flex-1 py-1.5 rounded-md font-semibold transition-colors cursor-pointer text-center ${
                  publishSubTab === 'novo'
                    ? 'bg-violet-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.newSiteSubTab}
              </button>
              <button
                type="button"
                onClick={() => setPublishSubTab('meus_sites')}
                className={`flex-1 py-1.5 rounded-md font-semibold transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 ${
                  publishSubTab === 'meus_sites'
                    ? 'bg-violet-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>{t.mySitesSubTab}</span>
                <span className="bg-slate-800 text-violet-300 px-1.5 py-0.2 rounded-full text-[10px]">
                  {userPublishedSites.length}
                </span>
              </button>
            </div>

            {/* SUBTAB: MEUS SITES PUBLICADOS */}
            {publishSubTab === 'meus_sites' && (
              <div className="space-y-3">
                {/* Explanatory banner confirming multiple sites support */}
                <div className="bg-violet-950/20 border border-violet-800/30 rounded-xl p-3 text-[11px] text-violet-200 leading-relaxed flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-violet-300 font-semibold mb-0.5">
                      {locale === 'pt' ? 'Suporte a múltiplos sites e atualizações:' : 'Multiple sites & updates support:'}
                    </strong>
                    {t.multiSitesExplainer}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-300">{t.mySitesTitle}</span>
                  {keypair && (
                    <button
                      type="button"
                      disabled={isSyncingMySites}
                      onClick={handleSyncMySites}
                      className="text-violet-400 hover:text-violet-300 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className={`w-3 h-3 ${isSyncingMySites ? 'animate-spin' : ''}`} />
                      {isSyncingMySites ? t.syncingFromRelays : t.syncFromRelaysBtn}
                    </button>
                  )}
                </div>

                {userPublishedSites.length === 0 ? (
                  <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 text-center text-slate-400 space-y-2">
                    <p className="font-medium text-slate-300 text-xs">{t.noSitesPublishedYet}</p>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {t.noSitesHint}
                    </p>
                    <button
                      type="button"
                      onClick={() => setPublishSubTab('novo')}
                      className="px-3.5 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      {t.newSiteSubTab}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {userPublishedSites.map((site) => (
                      <div
                        key={site.dTag}
                        className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="font-bold text-slate-100 text-xs block">{site.title}</span>
                            <span className="text-[10px] text-teal-400 font-mono">
                              d-tag: /{site.dTag}
                            </span>
                          </div>
                          {site.size ? (
                            <span className="text-[10px] text-slate-400 font-mono shrink-0">
                              {(site.size / 1024).toFixed(1)} KB
                            </span>
                          ) : null}
                        </div>

                        {site.description && (
                          <p className="text-slate-400 text-[11px] line-clamp-2">
                            {site.description}
                          </p>
                        )}

                        <div className="pt-1.5 border-t border-slate-800/80 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleStartUpdateSite(site)}
                            className="flex-1 py-1 px-2 bg-violet-600 hover:bg-violet-500 text-white rounded-md text-[11px] font-semibold text-center cursor-pointer transition-colors"
                          >
                            {t.updateVersionBtn}
                          </button>
                          <button
                            type="button"
                            onClick={() => onNavigateAddress(site.naddr)}
                            className="flex-1 py-1 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md text-[11px] font-medium text-center cursor-pointer transition-colors"
                          >
                            {t.openInBrowserBtn}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(site.naddr);
                              alert(t.naddrCopiedNotice);
                            }}
                            className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-md cursor-pointer"
                            title={t.copyNaddrBtn}
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SUBTAB: NOVO SITE / FORMULÁRIO DE PUBLICAÇÃO & ATUALIZAÇÃO */}
            {publishSubTab === 'novo' && (
              <form onSubmit={handlePublish} className="space-y-3.5">
                {!keypair ? (
                  <div className="bg-amber-950/30 border border-amber-800/40 rounded-xl p-3 text-xs text-amber-300 space-y-2">
                    <p className="font-medium">
                      {t.publishNeedAuthWarning}
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('conta')}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg cursor-pointer"
                    >
                      {t.connectNowBtn}
                    </button>
                  </div>
                ) : (
                  <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs">
                    <span className="text-slate-400">{t.signingAsLabel}</span>
                    <span className="font-mono text-violet-400 font-semibold truncate max-w-[200px]">
                      {keypair.npub.slice(0, 16)}...
                    </span>
                  </div>
                )}

                {/* Updating banner indicator */}
                {updatingSiteDTag && (
                  <div className="bg-teal-950/40 border border-teal-800/50 rounded-xl p-2.5 text-xs text-teal-300 flex items-center justify-between">
                    <div>
                      <span className="font-bold block">{t.updatingSiteBadge}</span>
                      <span className="font-mono text-[11px] text-teal-400">d-tag: {updatingSiteDTag}</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCancelUpdateMode}
                      className="text-[11px] text-slate-400 hover:text-slate-200 underline cursor-pointer"
                    >
                      {t.cancelUpdateMode}
                    </button>
                  </div>
                )}

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {t.dTagLabel}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={t.dTagPlaceholder}
                    value={publishDTag}
                    onChange={(e) => setPublishDTag(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '-'))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {t.dTagHint}
                  </span>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {t.titleLabel}
                  </label>
                  <input
                    type="text"
                    placeholder={t.titlePlaceholder}
                    value={publishTitle}
                    onChange={(e) => setPublishTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {t.descLabel}
                  </label>
                  <textarea
                    rows={2}
                    placeholder={t.descPlaceholder}
                    value={publishDescription}
                    onChange={(e) => setPublishDescription(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
                  />
                </div>

                {/* ZIP Upload Box */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-300 font-semibold">
                      {t.zipFileLabel}
                    </label>
                    <button
                      type="button"
                      disabled={isGeneratingSample}
                      onClick={handleGenerateSampleZip}
                      className="text-violet-400 hover:text-violet-300 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3" />
                      {isGeneratingSample ? t.generatingLabel : t.generateTestZipBtn}
                    </button>
                  </div>

                  <label className="border-2 border-dashed border-slate-800 hover:border-violet-500/70 bg-slate-950/60 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition-colors">
                    <UploadCloud className="w-7 h-7 text-violet-400 mb-1.5" />
                    <span className="text-xs font-medium text-slate-200">
                      {selectedZipName ? (
                        <span className="text-teal-400 font-mono flex items-center gap-1">
                          <FileArchive className="w-3.5 h-3.5" /> {selectedZipName}
                        </span>
                      ) : (
                        t.dragDropZipPrompt
                      )}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-1">
                      {t.zipRequirementHint}
                    </span>
                    <input
                      type="file"
                      accept=".zip"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Blossom Server Selector */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    {t.blossomServerLabel}
                  </label>
                  <select
                    value={publishBlossomServer}
                    onChange={(e) => setPublishBlossomServer(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none"
                  >
                    {DEFAULT_BLOSSOM_SERVERS.map((srv) => (
                      <option key={srv} value={srv}>
                        {srv}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Error / Step Progress */}
                {publishError && (
                  <div className="bg-red-950/30 border border-red-800/40 rounded-lg p-2.5 text-xs text-red-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{publishError}</span>
                  </div>
                )}

                {isPublishing && (
                  <div className="bg-violet-950/30 border border-violet-800/40 rounded-lg p-3 text-xs text-violet-300 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <RotateCw className="w-4 h-4 animate-spin text-violet-400" />
                      <span className="font-semibold">{publishStep}</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-violet-500 h-full w-2/3 animate-pulse" />
                    </div>
                  </div>
                )}

                {publishSuccessNaddr && (
                  <div className="bg-emerald-950/30 border border-emerald-800/40 rounded-xl p-3 text-xs text-emerald-300 space-y-2">
                    <div className="flex items-center gap-2 font-semibold text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{t.publishSuccessTitle}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded text-[10px] font-mono break-all text-slate-300 select-all border border-slate-800">
                      {publishSuccessNaddr}
                    </div>
                    <button
                      type="button"
                      onClick={() => onNavigateAddress(publishSuccessNaddr)}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-center cursor-pointer transition-colors"
                    >
                      {t.openPublishedSiteBtn}
                    </button>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isPublishing || !keypair}
                  className="w-full py-2.5 bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:hover:bg-violet-600 text-white font-bold rounded-lg shadow-lg shadow-violet-600/20 transition-all cursor-pointer"
                >
                  {isPublishing ? t.publishingBtn : t.publishBtn}
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 3: EXPLORAR SITES PÚBLICOS */}
        {activeTab === 'explorar' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300">{t.exploreTitle}</span>
              <button
                type="button"
                onClick={handleDiscoverSites}
                disabled={isDiscovering}
                className="text-violet-400 hover:text-violet-300 text-xs flex items-center gap-1 cursor-pointer font-medium"
              >
                <RefreshCw className={`w-3 h-3 ${isDiscovering ? 'animate-spin' : ''}`} />
                {isDiscovering ? t.fetchingRelaysLabel : t.fetchRelaysBtn}
              </button>
            </div>

            {discoveredSites.length === 0 ? (
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 text-center text-slate-400">
                <Globe className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="font-medium text-slate-300 mb-1">{t.noDiscoveredTitle}</p>
                <p className="text-[11px] mb-3">
                  {t.noDiscoveredSubtitle}
                </p>
                <button
                  type="button"
                  onClick={handleDiscoverSites}
                  className="px-3.5 py-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  {t.loadRelaysSitesBtn}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {discoveredSites.map((site, i) => (
                  <div
                    key={site.id || i}
                    className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-100">{site.title}</span>
                      <span className="text-[10px] text-teal-400 font-mono">/{site.dTag}</span>
                    </div>
                    {site.description && (
                      <p className="text-slate-400 text-[11px] line-clamp-2">
                        {site.description}
                      </p>
                    )}
                    <button
                      type="button"
                      onClick={() => onNavigateAddress(site.naddr)}
                      className="w-full mt-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-violet-300 rounded-lg text-center font-medium cursor-pointer"
                    >
                      {t.openSiteBtn}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: CONTA & CHAVES NOSTR */}
        {activeTab === 'conta' && (
          <div className="space-y-4">
            {keypair ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-300 font-bold">
                      🔑
                    </div>
                    <div>
                      <span className="font-semibold text-slate-100 text-xs block">{t.connectedLabel}</span>
                      <span className="text-[10px] text-teal-400 font-mono">
                        {keypair.type === 'nip07' ? t.typeNip07 : t.typeNsec}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSetKeypair(null)}
                    className="text-red-400 hover:text-red-300 text-xs cursor-pointer font-medium"
                  >
                    {t.disconnectBtn}
                  </button>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[11px] text-slate-400">{t.yourNpubLabel}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(keypair.npub);
                        setCopiedNpub(true);
                        setTimeout(() => setCopiedNpub(false), 2000);
                      }}
                      className="text-[11px] text-violet-400 hover:text-violet-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedNpub ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {copiedNpub ? t.copiedLabel : t.copyLabel}
                    </button>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg font-mono text-[10px] text-slate-300 break-all select-all border border-slate-800">
                    {keypair.npub}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Connect with nsec */}
                <form onSubmit={handleConnectNsec} className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
                  <span className="font-semibold text-slate-200 block text-xs">
                    {t.connectWithNsecLabel}
                  </span>
                  <div className="relative">
                    <input
                      type={showNsec ? 'text' : 'password'}
                      placeholder="nsec1... / hex"
                      value={nsecInput}
                      onChange={(e) => setNsecInput(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-violet-500 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none font-mono pr-8"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNsec(!showNsec)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                    >
                      {showNsec ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {authError && (
                    <span className="text-red-400 text-[11px] block">{authError}</span>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    {t.connectNsecBtn}
                  </button>
                </form>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-800"></div>
                  <span className="flex-shrink mx-2 text-slate-400 text-[11px]">{t.orDivider}</span>
                  <div className="flex-grow border-t border-slate-800"></div>
                </div>

                {/* Generate New Key */}
                <button
                  type="button"
                  onClick={onRequestCreateKey}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-violet-500/50 rounded-xl font-semibold text-violet-300 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <PlusCircle className="w-4 h-4 text-violet-400" />
                  {t.createNewKeyBtn}
                </button>

                {/* Connect via NIP-07 */}
                <button
                  type="button"
                  onClick={handleConnectNip07}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl font-medium text-slate-300 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Key className="w-3.5 h-3.5 text-teal-400" />
                  {t.connectNip07Btn}
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 5: RELAYS & GERENCIADOR DE CACHE */}
        {activeTab === 'relays' && (
          <div className="space-y-4">
            {/* Relays */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300 text-xs">{t.networkRelaysTitle}</span>
                <button
                  type="button"
                  onClick={handleTestRelays}
                  disabled={isTestingRelays}
                  className="text-violet-400 hover:text-violet-300 text-[11px] flex items-center gap-1 cursor-pointer font-medium"
                >
                  <Radio className={`w-3 h-3 ${isTestingRelays ? 'animate-pulse' : ''}`} />
                  {isTestingRelays ? t.testingRelaysLabel : t.testRelaysBtn}
                </button>
              </div>

              <div className="space-y-1.5">
                {DEFAULT_RELAYS.map((url) => {
                  const status = relayStatuses.find((r) => r.url === url);
                  return (
                    <div
                      key={url}
                      className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between"
                    >
                      <span className="font-mono text-[11px] text-slate-300 truncate max-w-[220px]">
                        {url}
                      </span>
                      {status ? (
                        status.connected ? (
                          <span className="text-[10px] text-emerald-400 font-mono">
                            Online ({status.ping}ms)
                          </span>
                        ) : (
                          <span className="text-[10px] text-red-400">Offline</span>
                        )
                      ) : (
                        <span className="text-[10px] text-slate-400 font-mono">Default</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Local Cache Management */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300 text-xs">
                  {t.localCacheTitle}
                </span>
                <button
                  type="button"
                  onClick={async () => {
                    const count = await clearExpiredCachedSites();
                    alert(t.removedExpiredNotice.replace('{count}', String(count)));
                    loadCacheData();
                  }}
                  className="text-teal-400 hover:text-teal-300 text-[11px] cursor-pointer"
                >
                  {t.clearExpiredBtn}
                </button>
              </div>

              <div className="space-y-1.5">
                {cachedSitesList.length === 0 ? (
                  <p className="text-slate-500 text-[11px]">{t.noCachedSites}</p>
                ) : (
                  cachedSitesList.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200 truncate max-w-[220px]">
                          {item.title}
                        </span>
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                            item.isExpired ? 'bg-red-950 text-red-400' : 'bg-teal-950 text-teal-400'
                          }`}
                        >
                          {item.isExpired ? t.expiredCacheBadge : t.activeCacheBadge}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span>{item.fileCount} {t.filesCountLabel}</span>
                        <button
                          type="button"
                          onClick={async () => {
                            await deleteCachedSite(item.siteKey);
                            loadCacheData();
                          }}
                          className="text-red-400 hover:text-red-300 cursor-pointer"
                        >
                          {t.deleteFromCacheBtn}
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950 text-[11px] text-slate-400 flex items-center justify-between">
        <span>WebP2P · Nostr NIP-5A</span>
        <span className="font-mono text-violet-400">{t.footerBadge}</span>
      </div>
    </aside>
  );
};
