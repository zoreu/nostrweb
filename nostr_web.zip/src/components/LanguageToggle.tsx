import React from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import { Globe } from 'lucide-react';

interface LanguageToggleProps {
  compact?: boolean;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({ compact = false }) => {
  const { locale, setLocale } = useLanguage();

  return (
    <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-[11px] font-medium">
      {!compact && <Globe className="w-3 h-3 text-slate-400 ml-1.5 shrink-0" />}
      <button
        type="button"
        onClick={() => setLocale('pt')}
        className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
          locale === 'pt'
            ? 'bg-violet-600 text-white font-bold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
        title="Português"
      >
        PT
      </button>
      <span className="text-slate-700">|</span>
      <button
        type="button"
        onClick={() => setLocale('en')}
        className={`px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
          locale === 'en'
            ? 'bg-violet-600 text-white font-bold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
        title="English"
      >
        EN
      </button>
    </div>
  );
};
