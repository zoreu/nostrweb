import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronRight,
  RotateCw,
  ArrowLeft,
  ArrowRight,
  Globe,
  SlidersHorizontal,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { NavigationState, NostrSiteMeta } from '../types';
import { useLanguage } from '../i18n/LanguageContext';
import { LanguageToggle } from './LanguageToggle';

interface BrowserFrameProps {
  isSidebarOpen: boolean;
  onOpenSidebar: () => void;
  // Browser state
  blobUrl: string | null;
  isLoading: boolean;
  loadingMessage: string;
  errorMessage: string | null;
  navState: NavigationState;
  canGoBack: boolean;
  canGoForward: boolean;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: () => void;
  onNavigateAddress: (address: string) => void;
  onIframeNavigate: (targetHref: string, isPushState?: boolean) => void;
  currentSiteMeta: NostrSiteMeta | null;
  isCached: boolean;
}

export const BrowserFrame: React.FC<BrowserFrameProps> = ({
  isSidebarOpen,
  onOpenSidebar,
  blobUrl,
  isLoading,
  loadingMessage,
  errorMessage,
  navState,
  canGoBack,
  canGoForward,
  onGoBack,
  onGoForward,
  onReload,
  onNavigateAddress,
  onIframeNavigate,
  currentSiteMeta,
  isCached,
}) => {
  const { t } = useLanguage();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [welcomeAddress, setWelcomeAddress] = useState('');

  // Listen to postMessage from the injected client bridge in the iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'WEBP2P_NAVIGATE') {
        const { href, isPushState } = event.data;
        if (href) {
          onIframeNavigate(href, isPushState);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onIframeNavigate]);

  return (
    <div
      className={`relative flex-1 h-screen flex flex-col bg-slate-950 transition-all duration-300 ${
        isSidebarOpen ? 'sm:ml-[480px]' : 'ml-0'
      }`}
    >
      {/* Top Floating Mini-Bar */}
      <div className="h-12 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md px-3 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center gap-2">
          {/* Expand Button: shown prominently when sidebar is hidden */}
          {!isSidebarOpen ? (
            <button
              type="button"
              onClick={onOpenSidebar}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600/90 hover:bg-violet-600 text-white rounded-lg text-xs font-semibold shadow-lg shadow-violet-600/20 transition-all cursor-pointer group"
              title={t.expandPanel}
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>{t.expandPanel}</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </button>
          ) : (
            <div className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>{t.viewerTitle}</span>
            </div>
          )}

          {/* Quick nav buttons when modal is closed */}
          {!isSidebarOpen && (
            <div className="flex items-center gap-1 pl-1">
              <button
                type="button"
                disabled={!canGoBack}
                onClick={onGoBack}
                className="p-1.5 rounded-md hover:bg-slate-800 disabled:opacity-30 text-slate-300 transition-colors cursor-pointer"
                title={t.backTooltip}
              >
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                disabled={!canGoForward}
                onClick={onGoForward}
                className="p-1.5 rounded-md hover:bg-slate-800 disabled:opacity-30 text-slate-300 transition-colors cursor-pointer"
                title={t.forwardTooltip}
              >
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={onReload}
                className="p-1.5 rounded-md hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer"
                title={t.reloadTooltip}
              >
                <RotateCw className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Current URL preview and parameters tag + Language Toggle */}
        <div className="flex items-center gap-2 max-w-[65%] truncate text-xs">
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-md text-slate-300 font-mono text-[11px] truncate">
            <Globe className="w-3 h-3 text-violet-400 shrink-0" />
            <span className="truncate">
              {navState.currentAddress || 'webp2p://'}
            </span>
          </div>

          {navState.rawSearch && (
            <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-mono bg-violet-950/60 border border-violet-800/50 text-violet-300 px-2 py-0.5 rounded shrink-0">
              <SlidersHorizontal className="w-2.5 h-2.5" />
              {navState.rawSearch}
            </span>
          )}

          {isCached && (
            <span className="hidden lg:inline-flex text-[10px] font-mono text-teal-400 bg-teal-950/40 border border-teal-800/40 px-2 py-0.5 rounded shrink-0">
              {t.cacheBadge}
            </span>
          )}

          {/* Language switcher */}
          <LanguageToggle compact={false} />
        </div>
      </div>

      {/* Main Viewport Container */}
      <div className="relative flex-1 w-full h-full overflow-hidden bg-slate-950 flex flex-col">
        {/* Floating Expand Tab on left edge when modal is closed */}
        {!isSidebarOpen && (
          <button
            type="button"
            onClick={onOpenSidebar}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-30 bg-slate-900 hover:bg-violet-600 text-slate-400 hover:text-white border-y border-r border-slate-700 hover:border-violet-500 rounded-r-xl py-3 px-1.5 shadow-2xl transition-all cursor-pointer flex flex-col items-center gap-1 group"
            title={t.expandPanel}
          >
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            <span className="text-[10px] font-bold uppercase [writing-mode:vertical-lr] tracking-widest text-slate-400 group-hover:text-white py-1">
              {t.menu}
            </span>
          </button>
        )}

        {/* Loading Overlay */}
        {isLoading && (
          <div className="absolute inset-0 z-20 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-200">
            <div className="w-12 h-12 rounded-xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-center text-violet-400 mb-4">
              <RotateCw className="w-6 h-6 animate-spin" />
            </div>
            <h3 className="text-slate-100 font-bold text-base mb-1">
              {t.loadingTitle}
            </h3>
            <p className="text-slate-400 text-xs max-w-sm">
              {loadingMessage || t.loadingDefaultMessage}
            </p>
          </div>
        )}

        {/* Error Overlay */}
        {errorMessage && !isLoading && (
          <div className="absolute inset-0 z-20 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-red-950/50 border border-red-800/40 flex items-center justify-center text-red-400 mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-slate-100 font-bold text-base mb-1">
              {t.errorTitle}
            </h3>
            <p className="text-slate-400 text-xs max-w-md mb-4 leading-relaxed">
              {errorMessage}
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onReload}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer"
              >
                {t.tryAgainBtn}
              </button>
              <button
                type="button"
                onClick={onOpenSidebar}
                className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                {t.openSitesMenuBtn}
              </button>
            </div>
          </div>
        )}

        {/* Sandboxed iframe */}
        {blobUrl ? (
          <iframe
            ref={iframeRef}
            src={blobUrl}
            title={navState.title || 'WebP2P Site'}
            sandbox="allow-scripts allow-forms allow-same-origin allow-modals allow-downloads"
            className="w-full h-full border-none bg-white"
          />
        ) : (
          !isLoading &&
          !errorMessage && (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-300 max-w-xl mx-auto">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center text-white shadow-xl shadow-violet-600/20 mb-4">
                <Zap className="w-7 h-7" />
              </div>
              <h2 className="text-xl font-bold text-slate-100 tracking-tight mb-2">
                {t.welcomeTitle}
              </h2>
              <p className="text-xs text-slate-400 mb-6 leading-relaxed max-w-md">
                {t.welcomeSubtitle}
              </p>

              {/* Direct address input */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (welcomeAddress.trim()) {
                    onNavigateAddress(welcomeAddress.trim());
                  }
                }}
                className="w-full flex items-center gap-2 mb-4"
              >
                <div className="relative flex-1">
                  <Globe className="w-4 h-4 text-violet-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder={t.welcomeInputPlaceholder}
                    value={welcomeAddress}
                    onChange={(e) => setWelcomeAddress(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 focus:border-violet-500 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 font-mono outline-none shadow-inner"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!welcomeAddress.trim()}
                  className="px-4 py-2.5 bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:hover:bg-violet-600 text-white text-xs font-semibold rounded-xl cursor-pointer transition-colors shadow-lg shadow-violet-600/20"
                >
                  {t.welcomeNavigateBtn}
                </button>
              </form>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onOpenSidebar}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium rounded-lg cursor-pointer transition-colors"
                >
                  {t.welcomeOpenPanelBtn}
                </button>
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
};
