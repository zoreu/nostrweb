import React, { useState } from 'react';
import { Copy, Check, ShieldAlert, KeyRound } from 'lucide-react';
import { NostrKeypair } from '../types';
import { useLanguage } from '../i18n/LanguageContext';

interface NewKeyModalProps {
  keypair: NostrKeypair;
  onConfirm: () => void;
  onCancel: () => void;
}

export const NewKeyModal: React.FC<NewKeyModalProps> = ({
  keypair,
  onConfirm,
  onCancel,
}) => {
  const { t } = useLanguage();
  const [copiedNsec, setCopiedNsec] = useState(false);
  const [copiedNpub, setCopiedNpub] = useState(false);
  const [confirmedBackup, setConfirmedBackup] = useState(false);

  const copyToClipboard = (text: string, isNsec: boolean) => {
    navigator.clipboard.writeText(text);
    if (isNsec) {
      setCopiedNsec(true);
      setTimeout(() => setCopiedNsec(false), 2000);
    } else {
      setCopiedNpub(true);
      setTimeout(() => setCopiedNpub(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-5 border-b border-slate-800 bg-slate-950/60 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-base">{t.modalNewKeyTitle}</h3>
            <p className="text-xs text-slate-400">{t.modalNewKeySubtitle}</p>
          </div>
        </div>

        <div className="p-5 space-y-4">
          <div className="bg-amber-950/30 border border-amber-800/40 rounded-lg p-3 text-xs text-amber-300 flex gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
            <p>{t.modalWarningText}</p>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-300">
                {t.modalPrivKeyLabel}
              </label>
              <button
                type="button"
                onClick={() => keypair.nsec && copyToClipboard(keypair.nsec, true)}
                className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedNsec ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedNsec ? t.copiedLabel : `${t.copyLabel} nsec`}
              </button>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 font-mono text-xs text-red-300 break-all select-all">
              {keypair.nsec}
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-300">
                {t.modalPubKeyLabel}
              </label>
              <button
                type="button"
                onClick={() => copyToClipboard(keypair.npub, false)}
                className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 cursor-pointer"
              >
                {copiedNpub ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedNpub ? t.copiedLabel : `${t.copyLabel} npub`}
              </button>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 font-mono text-xs text-slate-400 break-all select-all">
              {keypair.npub}
            </div>
          </div>

          <label className="flex items-start gap-2.5 pt-2 text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={confirmedBackup}
              onChange={(e) => setConfirmedBackup(e.target.checked)}
              className="mt-0.5 rounded border-slate-700 bg-slate-950 text-violet-600 focus:ring-violet-500"
            />
            <span>{t.modalBackupCheckbox}</span>
          </label>
        </div>

        <div className="p-4 bg-slate-950/70 border-t border-slate-800 flex justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            {t.cancelBtn}
          </button>
          <button
            type="button"
            disabled={!confirmedBackup}
            onClick={onConfirm}
            className="px-4 py-2 text-xs font-medium bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:hover:bg-violet-600 text-white rounded-lg transition-all cursor-pointer"
          >
            {t.saveAndConnectBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
